#!/bin/bash
# READ-ONLY diagnostics for QUANTAFORGE LXC deployment. Run as root on the host. Changes nothing.
echo "== which runtime =="; command -v incus lxc lxc-ls; incus version 2>&1; systemctl is-active incus incus.socket lxc-net 2>&1
echo "== incus instances (qf-* are panel-managed) =="; incus list 2>&1
echo "== legacy lxc containers =="; lxc-ls -f 2>&1
echo "== storage / networks / default profile =="; incus storage list 2>&1; incus network list 2>&1; incus profile show default 2>&1
echo "== bridges =="; ip -br addr show | grep -Ei 'incusbr|lxcbr|br' 
echo "== agent =="; systemctl status quantaforge-lxc --no-pager -l 2>&1 | tail -15; cat /etc/quantaforge/lxc-agent.env 2>/dev/null | sed -E 's/(TOKEN|PASS)[^=]*=.*/\1=***/'
curl -s --unix-socket /run/quantaforge/lxc.sock http://x/health; echo; curl -s --unix-socket /run/quantaforge/lxc.sock http://x/capacity; echo
echo "== image reachability =="; incus image list images: debian/13 2>&1 | head -5
echo "== recent logs =="; journalctl -u quantaforge-lxc -u quantaforge -n 40 --no-pager 2>&1 | tail -40
echo "== panel vps rows =="; sqlite3 /var/lib/quantaforge/quantaforge.db "select id,name,state,stage,progress,error from vps" 2>&1
