#!/usr/bin/env bash
# Pre-deploy credential audit. Usage (repo root): bash scripts/audit.sh [real.env ...]
cd "$(dirname "$0")/.." || exit 1; fail=0
# Project root may be /root: scan ONLY project items, never the whole directory.
ITEMS=(); for i in server.js package.json public lib scripts deploy install.sh README.md .gitignore; do [ -e "$i" ] && ITEMS+=("$i"); done
EX='--exclude-dir=node_modules --exclude-dir=.git --exclude-dir=data --exclude=*.env --exclude=audit.sh --exclude=.env.example'
echo "== .gitignore covers env files =="; grep -qE '^\.env' .gitignore && echo ok || { echo "FAIL"; fail=1; }
echo "== tracked env/db files =="; if git rev-parse >/dev/null 2>&1 && git ls-files | grep -E '(^|/)\.env$|\.db$'; then echo FAIL; fail=1; else echo ok; fi
echo "== hashes / private keys / filled-in secrets =="
if grep -rnE $EX '\$argon2|\$2[aby]\$|BEGIN (RSA|OPENSSH) PRIVATE|INITIAL_(ADMIN|USER)_PASSWORD=[^ ]|TUNNEL_TOKEN=[^ ]|eyJ[A-Za-z0-9_-]{30,}' "${ITEMS[@]}"; then echo FAIL; fail=1; else echo ok; fi
echo "== literal password assignments in code =="
if grep -rniE $EX "pass(word)?[a-z_]*\s*[:=]\s*[\"'][^\"']{6,}[\"']" server.js lib public scripts install.sh 2>/dev/null; then echo FAIL; fail=1; else echo ok; fi
for ENVF in "$@"; do
  [ -f "$ENVF" ] || { echo "skip (missing): $ENVF"; continue; }
  echo "== $ENVF: permissions & value-leak scan =="
  [ "$(stat -c %a "$ENVF")" = "600" ] && echo "perms ok" || { echo "FAIL: chmod 600 $ENVF"; fail=1; }
  while IFS='=' read -r k v; do case "$k" in INITIAL_*_PASSWORD|HOST_CONTROL_TOKEN|TUNNEL_TOKEN)
    v="${v%%#*}"; v="${v#\"}"; v="${v%\"}"; v="${v// /}"
    if [ -n "$v" ] && grep -rnF $EX -- "$v" "${ITEMS[@]}" >/dev/null; then echo "FAIL: value of $k found in project files"; fail=1; fi;; esac; done < "$ENVF"
done
[ $fail = 0 ] && echo "AUDIT PASSED" || { echo "AUDIT FAILED"; exit 1; }
