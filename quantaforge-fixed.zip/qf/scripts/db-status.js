'use strict';
// Read-only helper for install.sh. Prints: missing | empty | ready. Never prints hashes or secrets.
const fs = require('fs');
const p = process.env.DB_PATH;
if (!p || !fs.existsSync(p)) { console.log('missing'); process.exit(0); }
try {
  const Database = require('better-sqlite3');
  const db = new Database(p, { readonly: true, fileMustExist: true });
  const rows = db.prepare("SELECT role FROM creds").all().map(r => r.role);
  console.log(rows.includes('admin') && rows.includes('user') ? 'ready' : 'empty');
} catch (e) { console.log(/no such table/.test(e.message) ? 'empty' : 'error'); }
