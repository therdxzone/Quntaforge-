'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
let csrf = '', role = '', timer = null;
async function api(p, o = {}) {
  const r = await fetch('/api' + p, { method: o.method || 'GET', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: o.body ? JSON.stringify(o.body) : undefined });
  let d = {}; try { d = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(d.error || 'Request failed'); e.status = r.status; e.data = d; throw e; }
  return d;
}
function toast(m, bad) { const t = $('#toast'); t.textContent = m; t.className = 'toast show' + (bad ? ' bad' : ''); setTimeout(() => t.className = 'toast', 3500); }
const GB = b => b == null ? 'N/A' : (b / 2 ** 30).toFixed(1) + ' GB';
const pct = (a, b) => a == null || !b ? null : 100 * a / b;
const P = v => v == null ? 'N/A' : v.toFixed(1) + '%';
const upt = s => `${Math.floor(s / 86400)}d ${Math.floor(s % 86400 / 3600)}h ${Math.floor(s % 3600 / 60)}m`;
function applyBrand(b) {
  const st = document.documentElement.style; st.setProperty('--p', b.primary_color); st.setProperty('--s', b.secondary_color);
  document.title = b.panel_name; $$('.pname').forEach(e => e.textContent = b.panel_name); $$('.logo').forEach(i => i.src = b.logo_url); $('#pol').href = b.policy_url;
}
$('#acc').onchange = () => $('#loginBtn').disabled = !$('#acc').checked;
$('#loginForm').onsubmit = async e => {
  e.preventDefault(); $('#loginErr').textContent = '';
  try { const d = await api('/login', { method: 'POST', body: { username: $('#un').value, password: $('#pw').value, accepted: $('#acc').checked } }); $('#pw').value = ''; csrf = d.csrf; enter(d.role, d.mustChange); }
  catch (err) { $('#loginErr').textContent = err.message; }
};
$('#logout').onclick = async () => { try { await api('/logout', { method: 'POST' }); } catch {} location.reload(); };
function enter(r, mustChange) {
  role = r; $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
  $('#roleTag').textContent = r === 'admin' ? 'ADMIN' : 'USER';
  $$('.adminonly').forEach(e => e.classList.toggle('hidden', r !== 'admin'));
  $('#pwSec').classList.toggle('hidden', r !== 'admin');
  if (r === 'admin' && !mustChange) { loadAdminVps(); }
  $('#dash').classList.toggle('hidden', mustChange);
  if (mustChange) { $('#pwNote').textContent = 'You must change the initial admin password before continuing.'; $('#pwTarget').value = 'admin'; $('#pwTarget').classList.add('hidden'); return; }
  if (r === 'admin') loadSettings();
  tick(); clearInterval(timer); timer = setInterval(tick, 5000);
}
async function tick() {
  try {
    if (role === 'admin') { const d = await api('/admin/overview'); render(d.vps, d.os); chart(d.history); logs(d.logs); loadAdminVps(); } else render(await api('/vps'));
  } catch (e) { if (e.status === 401) location.reload(); }
}
function stat(label, val, p) { const d = document.createElement('div'); d.className = 'stat'; const s = document.createElement('span'); s.textContent = label; const b = document.createElement('b'); b.textContent = val; d.append(s, b);
  if (p != null) { const bar = document.createElement('div'); bar.className = 'bar'; const i = document.createElement('i'); i.style.width = Math.min(100, p) + '%'; bar.append(i); d.append(bar); } return d; }
function render(v, osn) {
  $('#host').textContent = v.hostname; $('#sub').textContent = `Plan: ${v.plan}` + ((osn || v.os) ? ` · ${osn || v.os}` : '') + (v.expires ? ` · Expires ${new Date(v.expires).toLocaleDateString()}` : '') + (v.stage ? ` · ${v.stage}` : '');
  const s = $('#status'); s.textContent = v.status; s.className = 'badge ' + v.status;
  const susp = v.status === 'Suspended';
  $('.warn').classList.toggle('hidden', !!v.container);   // the host-panel notice does not apply inside a user's own container
  $('#susp').classList.toggle('hidden', !(susp && role === 'user'));
  $('#sshx').disabled = (susp && role === 'user') || ['No VPS', 'Deploying', 'Expired', 'Unavailable', 'Stopped'].includes(v.status) && role === 'user';
  $('#stats').replaceChildren(
    stat('CPU allocation', v.cpuCores == null ? 'N/A' : `${v.cpuCores} vCPU` + (v.cpuLimit && v.cpuLimit < 100 ? ` (${v.cpuLimit}% limit)` : '')), stat('RAM allocation', GB(v.ramTotal)), stat('Storage allocation', GB(v.diskTotal)),
    stat('CPU usage', P(v.cpuPct), v.cpuPct), stat('RAM usage', `${GB(v.ramUsed)} (${P(pct(v.ramUsed, v.ramTotal))})`, pct(v.ramUsed, v.ramTotal)),
    stat('Disk usage', `${GB(v.diskUsed)} (${P(pct(v.diskUsed, v.diskTotal))})`, pct(v.diskUsed, v.diskTotal)), stat('Uptime', v.uptime == null ? 'N/A' : upt(v.uptime)));
  $('#upd').textContent = 'Last updated: ' + (v.updated ? new Date(v.updated).toLocaleTimeString() : 'N/A');
  $('#bSusp').disabled = susp; $('#bUnsusp').disabled = !susp;
  $('#modeNote').textContent = v.suspensionMode === 'host' ? 'Host-side controller configured: suspension is enforced by the hypervisor.' : 'Application-level suspension: blocks user access and SSHX only. The VM itself is NOT stopped.';
}
function chart(h) {
  const c = $('#chart'), x = c.getContext('2d'), W = c.width, H = c.height; x.clearRect(0, 0, W, H); x.strokeStyle = '#202938';
  for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(0, i * H / 4); x.lineTo(W, i * H / 4); x.stroke(); }
  const css = getComputedStyle(document.documentElement);
  [['cpu', css.getPropertyValue('--p')], ['ram', css.getPropertyValue('--s')]].forEach(([k, col]) => {
    x.strokeStyle = col.trim(); x.lineWidth = 2; x.beginPath(); let st = false;
    h.forEach((p, i) => { if (p[k] == null) return; const px = i * W / Math.max(1, h.length - 1), py = H - p[k] / 100 * H; st ? x.lineTo(px, py) : x.moveTo(px, py); st = true; }); x.stroke();
  });
}
function logs(rows) { $('#logs').replaceChildren(...rows.map(r => { const d = document.createElement('div'); const k = document.createElement('span'); k.className = 'k'; k.textContent = `[${r.kind}] `; d.append(new Date(r.ts).toLocaleString() + ' ', k, r.msg); return d; })); }
$('#logKind').onchange = async () => logs(await api('/admin/logs?kind=' + $('#logKind').value));
$('#sshx').onclick = async () => {
  $('#sshxMsg').textContent = 'Starting session…';
  try { const d = await api('/sshx', { method: 'POST' }); $('#sshxMsg').textContent = ''; window.open(d.url, '_blank', 'noopener,noreferrer'); }
  catch (e) { $('#sshxMsg').textContent = ''; toast(e.message, true); }
};
async function act(path, confirmMsg) {
  if (confirmMsg && !confirm(confirmMsg)) return;
  try { await api(path, { method: 'POST' }); toast('Done'); tick(); } catch (e) { toast(e.message, true); }
}
$('#bSusp').onclick = () => act('/admin/suspend', 'Suspend the VPS? Users will be blocked immediately.');
$('#bUnsusp').onclick = () => act('/admin/unsuspend', 'Unsuspend the VPS?');
$('#bRefresh').onclick = () => act('/admin/refresh');
$('#pwBtn').onclick = async () => {
  try { await api('/admin/password', { method: 'POST', body: { current: $('#pwCur').value, target: $('#pwTarget').value, newPassword: $('#pwNew').value } }); toast('Password updated. Please log in again.'); setTimeout(() => location.reload(), 1200); }
  catch (e) { toast(e.message, true); }
};
const FIELDS = [['panel_name', 'Panel name', 'text'], ['logo_url', 'Logo URL (https)', 'text'], ['policy_url', 'Policy website (https)', 'text'], ['primary_color', 'Primary color', 'color'], ['secondary_color', 'Secondary color', 'color'], ['plan_name', 'VPS plan name', 'text'],
  ['cpu_threshold', 'CPU threshold %', 'number'], ['ram_threshold', 'RAM threshold %', 'number'], ['duration_min', 'Consecutive minutes above threshold', 'number'], ['interval_s', 'Monitoring interval (seconds)', 'number'], ['auto_enabled', 'Automatic suspension enabled', 'checkbox']];
async function loadSettings() {
  const s = await api('/admin/settings'); const box = $('#setFields'); box.replaceChildren();
  for (const [k, l, t] of FIELDS) {
    const w = document.createElement('div'), lab = document.createElement('label'), i = document.createElement('input');
    lab.className = 'f'; lab.textContent = l; i.type = t; i.name = k; if (t === 'checkbox') { i.checked = s[k]; i.style.width = 'auto'; } else i.value = s[k]; w.append(lab, i); box.append(w);
  }
}
$('#setForm').onsubmit = async e => {
  e.preventDefault(); const body = {};
  for (const [k, , t] of FIELDS) { const i = $(`[name=${k}]`); body[k] = t === 'checkbox' ? i.checked : t === 'number' ? Number(i.value) : i.value; }
  try { await api('/admin/settings', { method: 'PUT', body }); toast('Settings saved'); applyBrand(await api('/branding')); } catch (er) { toast(er.message, true); }
};

// ---------- admin: users + VPS deployment ----------
const MB = n => n >= 1024 ? (n / 1024).toFixed(n % 1024 ? 1 : 0) + ' GB' : n + ' MB';
function el(t, c, x) { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
function btn(label, fn, cls = 'ghost') { const b = el('button', 'btn sm ' + cls, label); b.type = 'button'; b.onclick = fn; return b; }
async function run(path, o, confirmMsg, okMsg = 'Done') {
  if (confirmMsg && !confirm(confirmMsg)) return;
  try { await api(path, o || { method: 'POST' }); toast(okMsg); loadAdminVps(); } catch (e) { toast(e.message, true); }
}
let adminBusy = false;
async function loadAdminVps() {
  if (role !== 'admin' || adminBusy) return; adminBusy = true;
  try {
    const [users, vps, cap] = await Promise.all([api('/admin/users'), api('/admin/vps'), api('/admin/lxc')]);
    renderUsers(users); renderVps(vps); renderDeploy(users, cap);
  } catch (e) { if (e.status === 401) location.reload(); } finally { adminBusy = false; }
}
function renderUsers(users) {
  $('#userList').replaceChildren(...users.map(u => {
    const d = el('div', 'item'), t = el('div', 'grow'); t.append(el('b', '', u.username + ' '), el('span', 'badge ' + (u.status === 'active' ? 'Running' : 'Suspended'), u.status));
    t.append(el('div', 'muted small', (u.vps_name ? `VPS: ${u.vps_name} (${u.vps_state})` : 'No VPS') + (u.last_login ? ` · last login ${new Date(u.last_login).toLocaleString()}` : ' · never logged in')));
    const a = el('div', 'row wrapx');
    a.append(btn(u.status === 'active' ? 'Suspend' : 'Unsuspend', () => run(`/admin/users/${u.id}/${u.status === 'active' ? 'suspend' : 'unsuspend'}`, null, u.status === 'active' ? `Suspend ${u.username}? They are logged out immediately.` : null)),
      btn('Reset password', () => { const p = prompt(`New password for ${u.username} (12–128 characters):`); if (p) run(`/admin/users/${u.id}/password`, { method: 'POST', body: { password: p } }, null, 'Password reset'); }),
      btn('Delete', () => run(`/admin/users/${u.id}`, { method: 'DELETE' }, `Delete ${u.username}${u.vps_name ? ' AND destroy their VPS ' + u.vps_name : ''}? This cannot be undone.`), 'warnb'));
    d.append(t, a); return d;
  }));
  if (!users.length) $('#userList').append(el('p', 'muted small', 'No users yet.'));
}
function renderDeploy(users, cap) {
  const free = users.filter(u => !u.vps_name && u.status === 'active'), sel = $('#dUser'), cur = sel.value;
  if (sel.dataset.sig !== free.map(u => u.id).join()) { sel.replaceChildren(...free.map(u => { const o = el('option', '', u.username); o.value = u.id; return o; })); sel.dataset.sig = free.map(u => u.id).join(); if (cur) sel.value = cur; }
  const os = $('#dOs'); if (!os.options.length) cap.images.forEach(i => { const o = el('option', '', i.label); o.value = i.key; os.append(o); });
  $('#capNote').textContent = !cap.enabled ? 'LXC deployment is not enabled on this host (installer menu 4).' : cap.error ? 'LXC backend error: ' + cap.error
    : `Host: ${cap.cpuCores} cores · RAM available for new VPS ${MB(cap.maxRamMb)} (host free ${MB(cap.memAvailMb)}) · storage available ${cap.maxDiskGb} GB on ${cap.pool} (${cap.poolDriver})` + (cap.poolDriver === 'dir' ? ' · note: dir pools may not enforce disk quotas' : '');
  $('#dBtn').disabled = !cap.enabled || !!cap.error || !free.length;
}
function renderVps(list) {
  $('#vpsList').replaceChildren(...list.map(v => {
    const d = el('div', 'item'), t = el('div', 'grow'); t.append(el('b', '', v.name + ' '), el('span', 'badge ' + v.status, v.status));
    t.append(el('div', 'muted small', `${v.username} · ${v.osLabel} · ${v.cores} vCPU (${v.cpuLimit}%) · ${MB(v.ramMb)} RAM · ${v.diskGb} GB · expires ${new Date(v.expires).toLocaleDateString()}`));
    t.append(el('div', 'muted small', v.state === 'deploying' ? `${v.stage} (${v.progress}%)` : `IP ${v.ip || '—'} · CPU ${P(v.cpuPct)} · RAM ${v.ramUsed == null ? 'N/A' : MB(Math.round(v.ramUsed / 2 ** 20))} · Disk ${GB(v.diskUsed)} · Uptime ${v.uptime == null ? 'N/A' : upt(v.uptime)}`));
    if (v.error) t.append(el('div', v.state === 'failed' ? 'err' : 'muted small', v.error)); if (v.agentError) t.append(el('div', 'err', v.agentError));
    const a = el('div', 'row wrapx'), id = v.id, act = (x, c, m) => btn(x[0].toUpperCase() + x.slice(1), () => run(`/admin/vps/${id}/${x}`, { method: 'POST' }, c), m);
    if (v.state === 'active') a.append(act('start'), act('stop', `Stop ${v.name}?`), act('restart', `Restart ${v.name}?`));
    if (v.state === 'active') a.append(act('suspend', `Suspend ${v.name}? It is stopped and the user is blocked.`, 'warnb'));
    if (v.state === 'suspended') a.append(act('unsuspend', null, 'okb'));
    if (['active', 'suspended', 'expired'].includes(v.state)) a.append(act('rebuild', `Rebuild ${v.name}? ALL data inside the VPS is erased.`, 'warnb'), btn('Extend', () => { const d = Number(prompt('Extend by how many days (1–365)?', '30')); if (d) run(`/admin/vps/${id}/extend`, { method: 'POST', body: { days: d } }); }));
    if (v.state !== 'deploying') a.append(btn('Delete', () => run(`/admin/vps/${id}`, { method: 'DELETE' }, `Delete ${v.name}? The container and ALL its data are destroyed.`), 'warnb'));
    d.append(t, a); return d;
  }));
  if (!list.length) $('#vpsList').append(el('p', 'muted small', 'No VPS deployed yet.'));
}
$('#userForm').onsubmit = async e => {
  e.preventDefault();
  try { await api('/admin/users', { method: 'POST', body: { username: $('#nuName').value, password: $('#nuPw').value } }); $('#nuName').value = ''; $('#nuPw').value = ''; toast('User created'); loadAdminVps(); } catch (er) { toast(er.message, true); }
};
$('#deployForm').onsubmit = async e => {
  e.preventDefault(); const n = i => Number($(i).value);
  $('#dBtn').disabled = true; $('#dProg').classList.remove('hidden'); $('#dErr').textContent = ''; $('#dStage').textContent = 'Validating host resources…'; $('#dBar').style.width = '2%';
  let id;
  try { id = (await api('/admin/vps/deploy', { method: 'POST', body: { userId: n('#dUser'), os: $('#dOs').value, ramMb: n('#dRam'), cores: n('#dCores'), cpuLimit: n('#dLimit'), diskGb: n('#dDisk'), expiryDays: n('#dDays') } })).id; }
  catch (er) { $('#dErr').textContent = er.message; $('#dStage').textContent = 'Not deployed.'; $('#dBar').style.width = '0%'; loadAdminVps(); return; }
  for (;;) {
    let v; try { v = await api('/admin/vps/' + id); } catch (er) { $('#dErr').textContent = er.message; break; }
    $('#dStage').textContent = `${v.stage} (${v.progress}%)`; $('#dBar').style.width = Math.max(2, v.progress) + '%';
    if (v.state === 'failed') { $('#dErr').textContent = 'Deployment failed: ' + v.error; break; }
    if (v.state !== 'deploying') { $('#dStage').textContent = `${v.name} is ${v.status}.`; if (v.error) $('#dErr').textContent = v.error; toast(`VPS ${v.name} is running`); break; }
    await new Promise(r => setTimeout(r, 1500));
  }
  loadAdminVps();
};
(async () => {
  applyBrand(await fetch('/api/branding').then(r => r.json()));
  try { const d = await api('/me'); csrf = d.csrf; enter(d.role, d.mustChange); } catch {}
})();
