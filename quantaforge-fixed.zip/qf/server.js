'use strict';
require('dotenv').config();
const express = require('express'), helmet = require('helmet'), cookieParser = require('cookie-parser'), rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3'), argon2 = require('argon2'), crypto = require('crypto'), os = require('os'), fs = require('fs'), path = require('path');
const { execFile, spawn } = require('child_process');

const PORT = +process.env.PORT || 5000, HOST = process.env.HOST || '127.0.0.1';
const SECURE = process.env.COOKIE_SECURE !== 'false', SESSION_H = +process.env.SESSION_HOURS || 8;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'quantaforge.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS creds(role TEXT PRIMARY KEY, hash TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, role TEXT NOT NULL, csrf TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS acceptances(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, role TEXT NOT NULL, ip TEXT);
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, kind TEXT NOT NULL, msg TEXT NOT NULL);`);
try { db.exec('ALTER TABLE sessions ADD COLUMN uid INTEGER'); } catch {}   // sessions of admin-created users carry their user id

const DEFAULTS = {
  panel_name: 'QUANTAFORGE', logo_url: 'https://files.catbox.moe/brcc6g.png', policy_url: 'https://quantaforgeop.vercel.app/',
  primary_color: '#22D3EE', secondary_color: '#8B5CF6', plan_name: 'Standard',
  cpu_threshold: '90', ram_threshold: '95', duration_min: '5', interval_s: '60', auto_enabled: '0', suspended: '0'
};
const get = k => db.prepare('SELECT v FROM settings WHERE k=?').get(k)?.v ?? DEFAULTS[k];
const set = (k, v) => db.prepare('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, String(v));
const log = (kind, msg) => db.prepare('INSERT INTO logs(ts,kind,msg) VALUES(?,?,?)').run(Date.now(), kind, String(msg).slice(0, 500));
const isSusp = () => get('suspended') === '1';
const cred = r => db.prepare('SELECT * FROM creds WHERE role=?').get(r);
const verify = async (hash, pw) => { try { return await argon2.verify(hash, String(pw)); } catch { return false; } };
const hashPw = pw => argon2.hash(pw, { type: argon2.argon2id });
// The old shared 'user' password opens a HOST-level SSHX terminal. With LXC deployment enabled it is disabled unless explicitly re-enabled.
const LEGACY_USER = process.env.LEGACY_USER_LOGIN ? process.env.LEGACY_USER_LOGIN === 'true' : process.env.LXC_ENABLED !== 'true';
let DUMMY_HASH = null;   // equalises timing for unknown usernames

async function setup() {
  DUMMY_HASH = await hashPw(crypto.randomBytes(16).toString('hex'));
  for (const [role, env] of [['admin', 'INITIAL_ADMIN_PASSWORD'], ['user', 'INITIAL_USER_PASSWORD']]) {
    if (cred(role)) continue;
    const pw = process.env[env];
    if (!pw || pw.length < 8) { console.error(`FATAL: ${env} is not set (min 8 chars). Provide it via the protected environment file for first-time setup. No default is used.`); process.exit(1); }
    db.prepare('INSERT INTO creds(role,hash,must_change) VALUES(?,?,?)').run(role, await hashPw(pw), role === 'admin' ? 1 : 0);
    log('security', `${role} credential initialised (hashed)`);
  }
}

// ---------- metrics ----------
const cpuTimes = () => { let idle = 0, tot = 0; for (const c of os.cpus()) { for (const k in c.times) tot += c.times[k]; idle += c.times.idle; } return { idle, tot }; };
let prevCpu = cpuTimes(), cur = { cpu: null, mem: null, disk: null, ts: null }; const history = [];
function memInfo() {
  try { const m = fs.readFileSync('/proc/meminfo', 'utf8'); const g = k => +m.match(new RegExp(k + ':\\s+(\\d+)'))[1] * 1024; const total = g('MemTotal'); return { total, used: total - g('MemAvailable') }; }
  catch { const t = os.totalmem(); return { total: t, used: t - os.freemem() }; }
}
const diskInfo = () => new Promise(r => execFile('df', ['-kP', '/'], { timeout: 5000 }, (e, o) => {
  if (e) return r(null); const p = o.trim().split('\n')[1].split(/\s+/); r({ total: +p[1] * 1024, used: +p[2] * 1024 });
}));
async function sample() {
  const c = cpuTimes(), dt = c.tot - prevCpu.tot, di = c.idle - prevCpu.idle; prevCpu = c;
  const cpu = dt > 0 ? Math.max(0, Math.min(100, 100 * (1 - di / dt))) : cur.cpu;
  const mem = memInfo(); cur = { cpu, mem, disk: await diskInfo(), ts: Date.now() };
  history.push({ t: cur.ts, cpu, ram: 100 * mem.used / mem.total }); if (history.length > 120) history.shift();
}
function osName() { try { return fs.readFileSync('/etc/os-release', 'utf8').match(/PRETTY_NAME="?([^"\n]+)/)[1]; } catch { return `${os.type()} ${os.release()}`; } }
const hostMode = () => !!(process.env.HOST_CONTROL_URL && process.env.HOST_CONTROL_TOKEN);
const vps = () => ({
  status: isSusp() ? 'Suspended' : 'Running', hostname: os.hostname(), plan: get('plan_name'), cpuCores: os.cpus().length,
  cpuPct: cur.cpu, ramTotal: cur.mem?.total ?? null, ramUsed: cur.mem?.used ?? null,
  diskTotal: cur.disk?.total ?? null, diskUsed: cur.disk?.used ?? null, uptime: os.uptime(), updated: cur.ts,
  suspensionMode: hostMode() ? 'host' : 'application'
});

// ---------- suspension ----------
async function hostCall(action) {
  const r = await fetch(process.env.HOST_CONTROL_URL, { method: 'POST', signal: AbortSignal.timeout(10000),
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.HOST_CONTROL_TOKEN}` }, body: JSON.stringify({ action }) });
  if (!r.ok) throw new Error(`host controller HTTP ${r.status}`);
}
async function suspend(actor, reason) {
  if (isSusp()) return { ok: false, error: 'VPS is already suspended.' };
  set('suspended', '1'); killSshx();
  log('suspension', `${actor} suspended VPS (${reason}); mode=${hostMode() ? 'host' : 'application-level'}`);
  if (hostMode()) { try { await hostCall('suspend'); } catch (e) { set('suspended', '0'); log('error', 'host suspend failed: ' + e.message); return { ok: false, error: 'Host controller failed; VPS not suspended.' }; } }
  return { ok: true };
}
async function unsuspend(actor) {
  if (!isSusp()) return { ok: false, error: 'VPS is not suspended.' };
  if (hostMode()) { try { await hostCall('unsuspend'); } catch (e) { log('error', 'host unsuspend failed: ' + e.message); return { ok: false, error: 'Host controller failed.' }; } }
  set('suspended', '0'); log('suspension', `${actor} unsuspended VPS`); return { ok: true };
}

// ---------- auto-suspension ----------
let since = { cpu: null, ram: null }, monTimer;
function monitor() {
  if (get('auto_enabled') !== '1' || isSusp() || !cur.ts) { since = { cpu: null, ram: null }; return; }
  const now = Date.now(), dur = +get('duration_min') * 60000;
  for (const [n, v, th] of [['cpu', cur.cpu, +get('cpu_threshold')], ['ram', 100 * cur.mem.used / cur.mem.total, +get('ram_threshold')]]) {
    if (v != null && v >= th) {
      since[n] ??= now;
      if (now - since[n] >= dur) {
        log('suspension', `AUTO trigger: ${n}=${v.toFixed(1)}% >= ${th}% for ${Math.round((now - since[n]) / 1000)}s; action=suspend`);
        since = { cpu: null, ram: null }; suspend('system', `auto-${n}`).catch(e => log('error', e.message)); return;
      }
    } else since[n] = null;
  }
}
const schedule = () => { clearInterval(monTimer); monTimer = setInterval(monitor, +get('interval_s') * 1000); };

// ---------- SSHX ----------
let sshx = null;
function killSshx() { if (sshx) { try { sshx.proc.kill('SIGTERM'); } catch {} sshx = null; } }
const startSshx = () => new Promise((resolve, reject) => {
  if (sshx && sshx.proc.exitCode === null) return resolve(sshx.url);
  const proc = spawn(process.env.SSHX_BIN || 'sshx', ['-q'], { stdio: ['ignore', 'pipe', 'ignore'], env: { PATH: process.env.PATH, HOME: process.env.HOME, SHELL: process.env.SHELL, LANG: process.env.LANG } });
  let buf = '', done = false;
  const fin = (err, url) => { if (done) return; done = true; clearTimeout(to); if (err) { try { proc.kill(); } catch {} reject(err); } else resolve(url); };
  const to = setTimeout(() => fin(new Error('timeout')), 20000);
  proc.on('error', fin); proc.on('exit', () => { if (sshx && sshx.proc === proc) sshx = null; fin(new Error('exited')); });
  proc.stdout.on('data', d => { buf += d; const m = buf.match(/https?:\/\/\S+/); if (m) { sshx = { proc, url: m[0] }; fin(null, m[0]); } });
});

// ---------- sessions ----------
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
function newSession(role, res, uid = null) {
  const t = crypto.randomBytes(32).toString('hex'), csrf = crypto.randomBytes(24).toString('hex');
  db.prepare('INSERT INTO sessions(id,role,csrf,expires,uid) VALUES(?,?,?,?,?)').run(sha(t), role, csrf, Date.now() + SESSION_H * 3600e3, uid);
  res.cookie('qf_sid', t, { httpOnly: true, sameSite: 'strict', secure: SECURE, maxAge: SESSION_H * 3600e3, path: '/' });
  return csrf;
}
function auth(req, res, next) {
  const t = req.cookies.qf_sid, s = typeof t === 'string' && db.prepare('SELECT * FROM sessions WHERE id=? AND expires>?').get(sha(t), Date.now());
  if (!s) return res.status(401).json({ error: 'Not authenticated.' });
  if (s.uid) { const u = db.prepare('SELECT status FROM users WHERE id=?').get(s.uid); if (!u || u.status !== 'active') { db.prepare('DELETE FROM sessions WHERE id=?').run(s.id); return res.status(401).json({ error: 'Not authenticated.' }); } }
  else if (s.role === 'user' && !LEGACY_USER) { db.prepare('DELETE FROM sessions WHERE id=?').run(s.id); return res.status(401).json({ error: 'Not authenticated.' }); }
  if (!['GET', 'HEAD'].includes(req.method) && req.get('x-csrf-token') !== s.csrf) return res.status(403).json({ error: 'Invalid CSRF token.' });
  req.sess = s; next();
}
const need = role => (req, res, next) => req.sess.role === role ? next() : res.status(403).json({ error: 'Forbidden.' });
const adminOnly = [auth, need('admin'), (req, res, next) => cred('admin').must_change ? res.status(403).json({ error: 'Change the initial admin password first.', mustChange: true }) : next()];

// ---------- validation ----------
const httpsUrl = v => { try { const u = new URL(v); return u.protocol === 'https:' && v.length <= 300; } catch { return false; } };
const num = (a, b) => v => { const n = Number(v); return Number.isFinite(n) && n >= a && n <= b; };
const str = n => v => typeof v === 'string' && v.trim().length >= 1 && v.length <= n;
const V = { panel_name: str(40), plan_name: str(60), logo_url: httpsUrl, policy_url: httpsUrl,
  primary_color: v => /^#[0-9a-fA-F]{6}$/.test(v), secondary_color: v => /^#[0-9a-fA-F]{6}$/.test(v),
  cpu_threshold: num(1, 100), ram_threshold: num(1, 100), duration_min: num(1, 120), interval_s: num(10, 3600), auto_enabled: v => v === true || v === false };

// ---------- app ----------
const app = express();
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'https:', 'data:'], connectSrc: ["'self'"], frameAncestors: ["'none'"], objectSrc: ["'none'"] } } }));
app.use(express.json({ limit: '20kb' })); app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
const jsonLimit = (max, windowMs, error) => rateLimit({ windowMs, max, standardHeaders: true, legacyHeaders: false, handler: (q, r) => r.status(429).json({ error }) });
const loginLimiter = jsonLimit(8, 15 * 60e3, 'Too many attempts. Try again in 15 minutes.');
const sensitive = jsonLimit(20, 15 * 60e3, 'Too many requests. Slow down.');

app.get('/api/branding', (q, r) => r.json(Object.fromEntries(['panel_name', 'logo_url', 'primary_color', 'secondary_color', 'policy_url'].map(k => [k, get(k)]))));

app.post('/api/login', loginLimiter, async (req, res) => {
  const { password, accepted } = req.body || {};
  const uname = typeof (req.body || {}).username === 'string' ? req.body.username.trim().toLowerCase() : '';
  if (accepted !== true) return res.status(400).json({ error: 'You must accept the policies to continue.' });
  if (typeof password !== 'string' || !password || password.length > 256) return res.status(400).json({ error: 'Enter your password.' });
  if (uname) {                                   // admin-created user: username + password (hash in DB, fixed until the admin resets it)
    const u = vpsm.USER_RE.test(uname) ? db.prepare('SELECT * FROM users WHERE username=?').get(uname) : null;
    const good = await verify(u ? u.hash : DUMMY_HASH, password) && !!u;
    if (!good) { log('security', `failed login for user "${uname.slice(0, 32)}" from ${req.ip}`); return res.status(401).json({ error: 'Incorrect username or password.' }); }
    if (u.status !== 'active') { log('security', `login blocked (suspended account) ${u.username} from ${req.ip}`); return res.status(403).json({ error: 'Your account has been suspended. Please contact the admin.' }); }
    db.prepare('INSERT INTO acceptances(ts,role,ip) VALUES(?,?,?)').run(Date.now(), 'user', req.ip);
    db.prepare('UPDATE users SET last_login=? WHERE id=?').run(Date.now(), u.id); log('admin', `user login: ${u.username} from ${req.ip}`);
    return res.json({ role: 'user', csrf: newSession('user', res, u.id), mustChange: false, vpsUser: true });
  }
  let role = null;
  for (const r of ['admin', 'user']) { if (r === 'user' && !LEGACY_USER) continue; const c = cred(r); if (c && await verify(c.hash, password)) { role = r; break; } }
  if (!role) { log('security', `failed login from ${req.ip}`); return res.status(401).json({ error: 'Incorrect password.' }); }
  db.prepare('INSERT INTO acceptances(ts,role,ip) VALUES(?,?,?)').run(Date.now(), role, req.ip);
  if (role === 'admin') log('admin', `admin login from ${req.ip}`);
  const csrf = newSession(role, res);
  res.json({ role, csrf, mustChange: role === 'admin' && !!cred('admin').must_change });
});
app.post('/api/logout', auth, (req, res) => { db.prepare('DELETE FROM sessions WHERE id=?').run(req.sess.id); res.clearCookie('qf_sid'); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json({ role: req.sess.role, csrf: req.sess.csrf, mustChange: req.sess.role === 'admin' && !!cred('admin').must_change, vpsUser: !!req.sess.uid }));

app.get('/api/vps', auth, async (req, res) => {
  if (!req.sess.uid) return res.json(vps());                 // admin / legacy: the panel host, exactly as before
  try { res.json(await vpsm.userVps(req.sess.uid)); } catch (e) { log('error', 'user vps: ' + e.message); res.status(502).json({ error: 'Your VPS could not be queried right now.' }); }
});

app.post('/api/sshx', auth, sensitive, async (req, res) => {
  if (req.sess.uid) {                                        // VPS users: SSHX runs INSIDE their own container only, never on the host
    try { return res.json({ url: await vpsm.openSshx(req.sess.uid) }); }
    catch (e) { if (!e.status) log('error', 'SSHX (user) failed: ' + e.message); return res.status(e.status && e.status < 600 ? e.status : 503).json({ error: e.status && e.status < 500 ? e.message : 'SSHX is unavailable. No session was created.' }); }
  }
  if (isSusp() && req.sess.role !== 'admin') return res.status(403).json({ error: 'Your VPS Has Been Suspended' });
  if (req.sess.role === 'admin' && cred('admin').must_change) return res.status(403).json({ error: 'Change the initial admin password first.' });
  try { const url = await startSshx(); log('admin', `SSHX session opened by ${req.sess.role}`); res.json({ url }); }
  catch (e) { log('error', 'SSHX unavailable: ' + e.message); res.status(503).json({ error: 'SSHX is unavailable. No session was created.' }); }
});

// admin
app.post('/api/admin/password', auth, need('admin'), sensitive, async (req, res) => {
  const { current, target, newPassword } = req.body || {};
  if (!['admin', 'user'].includes(target) || typeof newPassword !== 'string' || newPassword.length < 12 || newPassword.length > 128) return res.status(400).json({ error: 'New password must be 12–128 characters.' });
  if (!await verify(cred('admin').hash, current)) { log('security', 'password change rejected: wrong current admin password'); return res.status(401).json({ error: 'Current admin password is incorrect.' }); }
  const other = cred(target === 'admin' ? 'user' : 'admin');
  if (await verify(other.hash, newPassword) || await verify(cred(target).hash, newPassword)) return res.status(400).json({ error: 'New password must differ from the existing admin/user passwords.' });
  db.prepare('UPDATE creds SET hash=?, must_change=0 WHERE role=?').run(await hashPw(newPassword), target);
  db.prepare('DELETE FROM sessions WHERE role=? AND uid IS NULL').run(target);
  log('admin', `${target} password changed`); res.clearCookie('qf_sid');
  res.json({ ok: true, relogin: true });
});
app.get('/api/admin/overview', adminOnly, (req, res) => res.json({ vps: vps(), os: osName(), history, logs: db.prepare('SELECT ts,kind,msg FROM logs ORDER BY id DESC LIMIT 12').all() }));
app.post('/api/admin/refresh', adminOnly, async (req, res) => { await sample(); res.json({ vps: vps(), os: osName(), history }); });
app.post('/api/admin/suspend', adminOnly, sensitive, async (req, res) => { const r = await suspend('admin', 'manual'); res.status(r.ok ? 200 : 409).json(r); });
app.post('/api/admin/unsuspend', adminOnly, sensitive, async (req, res) => { const r = await unsuspend('admin'); res.status(r.ok ? 200 : 409).json(r); });
app.get('/api/admin/logs', adminOnly, (req, res) => {
  const k = ['admin', 'suspension', 'security', 'error'].includes(req.query.kind) ? req.query.kind : null;
  res.json(k ? db.prepare('SELECT ts,kind,msg FROM logs WHERE kind=? ORDER BY id DESC LIMIT 200').all(k) : db.prepare('SELECT ts,kind,msg FROM logs ORDER BY id DESC LIMIT 200').all());
});
app.get('/api/admin/settings', adminOnly, (req, res) => {
  const o = Object.fromEntries(Object.keys(V).map(k => [k, get(k)])); o.auto_enabled = get('auto_enabled') === '1'; res.json(o);
});
app.put('/api/admin/settings', adminOnly, sensitive, (req, res) => {
  const b = req.body || {};
  for (const k of Object.keys(b)) if (!V[k] || !V[k](b[k])) return res.status(400).json({ error: `Invalid value for ${k}.` });
  for (const k of Object.keys(b)) set(k, k === 'auto_enabled' ? (b[k] ? '1' : '0') : typeof b[k] === 'string' ? b[k].trim() : b[k]);
  log('admin', `settings updated: ${Object.keys(b).join(', ')}`); schedule(); res.json({ ok: true });
});

const vpsm = require('./lib/vpsmgr')({ db, auth, adminOnly, sensitive, log, hashPw, get, app, killSessions: uid => db.prepare('DELETE FROM sessions WHERE uid=?').run(uid) });

app.use('/api', (q, r) => r.status(404).json({ error: 'Not found.' }));
app.use((err, req, res, next) => { log('error', err.message); res.status(500).json({ error: 'Internal server error.' }); });

(async () => {
  await setup(); db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
  await sample(); setInterval(() => sample().catch(e => log('error', e.message)), 5000); schedule();
  app.listen(PORT, HOST, () => console.log(`QUANTAFORGE listening on ${HOST}:${PORT}`));
})();
