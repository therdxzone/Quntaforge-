# QUANTAFORGE — single-VPS panel (smart installer, Cloudflare first)

Node 18+/Express, SQLite, Argon2id, server-side sessions (HttpOnly + SameSite=Strict cookie, CSRF header), strict CSP. Served to the internet only through a Cloudflare Tunnel; the panel listens on `127.0.0.1:5000`.

## Install (Debian/Ubuntu, RHEL-family, openSUSE or Arch VPS with systemd, as root)
```bash
unzip quantaforge.zip -d /root     # files land directly in /root (no nested folder)
cd /root && bash install.sh        # opens the menu
```
Project directory is `/root`, installer is `/root/install.sh`. The installer only touches the project items in `/root` (`server.js`, `package.json`, `public/`, `deploy/`, `scripts/`, `node_modules/`, `install.sh`, docs) — never other files in `/root`, and it never uses `chmod 777`.

### Menu
1 Install · 2 Connect/Reconfigure Cloudflare · 3 Check Cloudflare · 4 Start · 5 Restart · 6 Full status · 7 Cloudflare logs · 8 App logs · 9 Update · 10 Exit.
Also non-interactive: `bash install.sh status|cflogs|applogs|check|start|restart|update|install`.

### What "Install" does (fixed order)
1. **Cloudflare first** — asks for the tunnel token (hidden; pasting the whole `cloudflared service install <token>` command works), rejects empty/malformed input, saves it to `/etc/quantaforge/cloudflared.env` (root:root 0600), installs `quantaforge-cloudflared.service` (runs `cloudflared tunnel --protocol http2`), starts it.
2. **Verifies the connection** (a running service alone is not accepted): cloudflared installed → token saved → service active → process running → edge connections reported by cloudflared (`/ready` metrics, or "Registered tunnel connection" in the current invocation's log). Failures show `[✗] FAILED`, the real (redacted) error classified as authentication / DNS / network, and a menu: **Retry, Reconfigure Token, View Logs, Abort**.
3. **Only then the panel**: project files → missing dependencies only → env validation → port 5000 free → `quantaforge.service` → active → health check on `http://127.0.0.1:5000` → localhost-only + auth check → tunnel ingress routes to `127.0.0.1:5000` → public HTTPS URL verified → security audit → final dashboard.

The public URL is printed **only after** an HTTPS request to the hostname actually returns the panel. If the tunnel is connected but the Public Hostname is missing or points to another port, that is reported separately.

### Cloudflare side (one time)
Zero Trust → Networks → Tunnels → *your tunnel* → **Public Hostname** → Add: your domain, service **HTTP**, URL `127.0.0.1:5000`. Do **not** open port 5000 in any firewall.

### Re-running / recovery
Safe at any time. Nothing is deleted. DB is copied to `/var/lib/quantaforge/backups/<timestamp>/` and env files to `/etc/quantaforge/backups/` before the app is (re)started. Existing credentials are kept; initial passwords are asked only when the DB has none and are removed from the env file once the DB is initialised.

## Users and one-click LXC VPS
**Login:** leave *Username* empty for the admin (unchanged); admin-created users sign in with username + password. Passwords are Argon2id hashes only. A user cannot change their own credentials; only the admin can reset them (Users card → *Reset password*). Suspending or deleting a user ends their sessions immediately.

**Admin panel (existing look, new cards):** *Users* (create / suspend / reset password / delete), *Deploy VPS* (user, OS, RAM, CPU cores, CPU limit %, storage, expiry days; shows live progress and the real error if something fails) and *Deployed VPS* (start, stop, restart, rebuild, suspend, extend, delete). Success is shown only after the container is observed `Running`. One VPS per user.

**User dashboard:** same design; name, OS, status, allocated CPU/RAM/storage, live usage and uptime come from the user's own container. *Open SSHX* starts SSHX **inside that container** — never on the host.

**How it is isolated:** the panel (unprivileged) talks over a unix socket (`/run/quantaforge/lxc.sock`, root:quantaforge 0660) to `quantaforge-lxc.service`, a small root agent (`lib/lxc-agent.js`) that runs a fixed set of operations through `incus`/`lxc` and only touches instances it created (`qf-xxxxxxxx` + config `user.quantaforge=1`). A user's VPS is always derived from their session, never from a client-supplied id. Resource limits are enforced by LXC (`limits.cpu`, `limits.cpu.allowance`, `limits.memory`, root disk quota). Host totals are validated before every deploy (RAM and storage allocations may not exceed 85% / 90% of the host; cores may not exceed host cores). Expired VPS are stopped automatically until the admin extends or deletes them.

**Host requirements:** Debian 13 / Ubuntu 24.04+ (Incus), or LXD; the installer (menu 4) offers to install Incus and create a btrfs-loop pool (real disk quotas) with a NAT bridge. The containers need outbound internet for SSHX. The SSHX binary is copied into each container at deploy time.

**The old shared "user" password** opens a host-level SSHX terminal, so it is **disabled automatically when LXC deployment is enabled** (`LEGACY_USER_LOGIN=true` re-enables it; not recommended).

## Files
| Path | Purpose |
|---|---|
| `/root/lib/` | `vpsmgr.js` (users/VPS API), `lxc-agent.js` (root agent), `images.js` (OS allow-list) |
| `/etc/quantaforge/lxc-agent.env` | Agent config. root:root 0600 |
| `/root/*` | Project (read-only bind-mounted into the service; `/root` is otherwise hidden from it) |
| `/etc/quantaforge/quantaforge.env` | Panel config. root:root 0600 |
| `/etc/quantaforge/cloudflared.env` | Tunnel token only. root:root 0600, never on a command line |
| `/var/lib/quantaforge/quantaforge.db` | SQLite DB (Argon2id hashes only) |

## Operate
```bash
systemctl status quantaforge quantaforge-cloudflared quantaforge-lxc
journalctl -u quantaforge -n 50 --no-pager ; journalctl -u quantaforge-cloudflared -n 50 --no-pager
bash /root/scripts/audit.sh /etc/quantaforge/quantaforge.env /etc/quantaforge/cloudflared.env
```

## Troubleshooting
- **Tunnel not connected**: authentication error → wrong/revoked token (menu 2); DNS/network error → VPS cannot reach Cloudflare (outbound 443/7844). `curl -s http://127.0.0.1:20241/ready` shows connections.
- **Error 1033/502 on the public URL**: Public Hostname missing or not `http://127.0.0.1:5000`.
- **Deploy fails / agent unreachable**: `systemctl status quantaforge-lxc`, `journalctl -u quantaforge-lxc -n 50`, `incus list`. Disk quota errors mean the pool is a plain `dir` pool - use btrfs/zfs/lvm.
- **Login 429**: 8 attempts/15 min per IP; `TRUST_PROXY=true` is set by the installer.
- **SSHX unavailable**: `ls -l /usr/local/bin/sshx`; install from https://sshx.io and re-run menu 4.
- **Forgot admin password**: `systemctl stop quantaforge`, back up the DB, `sqlite3 /var/lib/quantaforge/quantaforge.db "DELETE FROM creds WHERE role='admin'"`, add an `INITIAL_ADMIN_PASSWORD` line (value in double quotes) to the env file, `systemctl start quantaforge`, then remove that line.

## Security notes
- The panel runs as unprivileged `quantaforge` (NoNewPrivileges, ProtectSystem=full, `ProtectHome=tmpfs` so it sees only the read-only project bind mounts of `/root`). It deliberately does **not** run as root: an SSHX terminal runs as the same account and would otherwise be a root shell.
- SSHX caveat: a terminal user can read/modify `/var/lib/quantaforge`. Only share the *user* password with people you trust.
- Real VM suspension needs a host-side controller (`HOST_CONTROL_URL` / `HOST_CONTROL_TOKEN`); otherwise suspension is application-level only.
- Never commit env files; `.gitignore` excludes them and `.db` files.
