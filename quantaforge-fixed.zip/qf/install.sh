#!/usr/bin/env bash
# QUANTAFORGE smart installer  —  /root/install.sh
# Order is fixed: Cloudflare Tunnel connects FIRST (verified from real connection indicators), then the panel starts.
# Secrets are read hidden, stored only in root-owned 0600 files, never put on a command line and never printed.
# Usage: bash install.sh [menu|install|cloudflare|check|start|restart|status|cflogs|applogs|update]   (default: menu)
set -o pipefail
set +x

# ---------- layout ----------
APP_DIR=/root; CONF_DIR=/etc/quantaforge; DATA_DIR=/var/lib/quantaforge; SVC_USER=quantaforge
APP_SVC=quantaforge; CF_SVC=quantaforge-cloudflared; LXC_SVC=quantaforge-lxc
LXC_ENV=$CONF_DIR/lxc-agent.env; AGENT_SOCK=/run/quantaforge/lxc.sock
PORT=5000; BIND=127.0.0.1; METRICS=127.0.0.1:20241
ENV_FILE=$CONF_DIR/quantaforge.env; CF_ENV=$CONF_DIR/cloudflared.env; DB_PATH=$DATA_DIR/quantaforge.db
HEALTH_URL="http://127.0.0.1:$PORT/api/branding"
# Only these items are ever copied / chmod-ed / chown-ed inside /root. Nothing else in /root is touched.
PROJECT_ITEMS=(server.js package.json package-lock.json public lib deploy scripts install.sh README.md .env.example .gitignore)
CURL=(curl -fsSL --retry 3 --connect-timeout 15)
CF_WAIT=${CF_WAIT:-75}
NODE_BIN=; CF_BIN=; SSHX_PATH=/usr/local/bin/sshx; PM=; CF_ARCH=; CF_TOKEN=; ADMIN_PW=; USER_PW=
ROUTE_STATE=noconfig; ROUTE_MSG=; PUB_STATE=unavailable; PUB_URL=; PUB_MSG=; GOOD_HOSTS=(); BAD_ROUTES=()

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B=; G=; Y=; R=; N=; fi
step() { echo; echo "${B}==> $*${N}"; }
ok()   { echo "  ${G}[✓]${N} $*"; }
bad()  { echo "  ${R}[✗] FAILED${N} $*"; }
warn() { echo "  ${Y}[!]${N} $*"; }
info() { echo "      $*"; }
redact() { sed -E -e 's/eyJ[A-Za-z0-9_=+\/.-]{10,}/[REDACTED]/g' -e 's/(TUNNEL_TOKEN|[Tt]oken)([=: ]+)[^ ]{20,}/\1\2[REDACTED]/g' -e 's/[A-Za-z0-9+\/_=-]{80,}/[REDACTED]/g'; }

# ---------- pure helpers (unit-testable) ----------
q() { local s=${1//\\/\\\\}; s=${s//\"/\\\"}; printf '"%s"' "$s"; }          # systemd EnvironmentFile quoting
env_has() { grep -q "^$2=" "$1" 2>/dev/null; }
env_get() { local l; l=$(grep -m1 "^$2=" "$1" 2>/dev/null) || return 1; l=${l#*=}; l=${l#\"}; l=${l%\"}; l=${l//\\\"/\"}; l=${l//\\\\/\\}; printf '%s' "$l"; }
env_set() { local f=$1 k=$2 v=$3 t; t=$(mktemp "$f.XXXXXX"); { grep -v "^${k}=" "$f" 2>/dev/null || true; printf '%s=%s\n' "$k" "$v"; } > "$t"; cat "$t" > "$f"; rm -f "$t"; }
normalize_token() { local t=${1//$'\r'/}; t=${t//$'\t'/ }; t=${t%"${t##*[! ]}"}; printf '%s' "${t##* }"; }  # also accepts a pasted "cloudflared service install <token>"
valid_token() { [[ "$1" =~ ^[A-Za-z0-9+/_=.-]{40,}$ ]]; }
valid_pw() { local p=$1; [ ${#p} -ge 12 ] && [ ${#p} -le 128 ] && [[ "$p" != *[[:cntrl:]]* ]] && [[ "$p" != " "* ]] && [[ "$p" != *" " ]]; }
route_ok_service() { [[ "$1" =~ ^https?://(127\.0\.0\.1|localhost):$PORT/?$ ]]; }

# ---------- prompts ----------
tty_ok() { [ -r /dev/tty ] && (: </dev/tty) 2>/dev/null; }
ask_secret() { local __v; IFS= read -rsp "$1" __v </dev/tty >&2 || { echo >&2; return 1; }; echo >&2; printf -v "$2" '%s' "$__v"; }
ask() { local __v; IFS= read -rp "$1" __v </dev/tty >&2 || return 1; printf -v "$2" '%s' "$__v"; }
confirm() { local a; read -rp "$1 [$2] " a </dev/tty >&2 || a=; a=${a:-$2}; [[ "$a" =~ ^[Yy] ]]; }

# ---------- platform / packages ----------
detect_platform() {
  [ "$(uname -s)" = Linux ] || { bad "Linux only."; return 1; }
  [ -d /run/systemd/system ] || { bad "systemd is required (PID 1 is not systemd)."; return 1; }
  local distro=unknown; if [ -r /etc/os-release ]; then distro=$(. /etc/os-release; echo "${PRETTY_NAME:-unknown}"); fi
  if command -v apt-get >/dev/null; then PM=apt; elif command -v dnf >/dev/null; then PM=dnf; elif command -v yum >/dev/null; then PM=yum
  elif command -v zypper >/dev/null; then PM=zypper; elif command -v pacman >/dev/null; then PM=pacman
  else bad "No supported package manager (apt, dnf, yum, zypper, pacman)."; return 1; fi
  case "$(uname -m)" in x86_64|amd64) CF_ARCH=amd64;; aarch64|arm64) CF_ARCH=arm64;; armv7l|armv6l) CF_ARCH=arm;; i?86) CF_ARCH=386;; *) CF_ARCH=;; esac
  ok "System: $distro | package manager: $PM | arch: $(uname -m)"
}
pkg_install() {
  case $PM in
    apt) DEBIAN_FRONTEND=noninteractive apt-get install -y "$@";;
    dnf) dnf install -y "$@";; yum) yum install -y "$@";;
    zypper) zypper --non-interactive install --no-recommends "$@";;
    pacman) pacman -S --needed --noconfirm "$@";;
  esac
}
ensure_min_tools() {            # only installs what is missing
  [ -n "$PM" ] || detect_platform || return 1
  local c missing=0; for c in curl tar ss; do command -v "$c" >/dev/null 2>&1 || missing=1; done
  [ -f /etc/ssl/certs/ca-certificates.crt ] || [ -d /etc/pki/tls/certs ] || [ -d /etc/ssl/certs ] || missing=1
  if [ $missing = 0 ]; then ok "Base tools present (curl, tar, ss)"; return 0; fi
  case $PM in
    apt) apt-get update -y >/dev/null; pkg_install ca-certificates curl gnupg tar gzip iproute2 util-linux;;
    dnf|yum) pkg_install ca-certificates curl gnupg2 tar gzip iproute util-linux;;
    zypper) pkg_install ca-certificates curl gpg2 tar gzip iproute2 util-linux;;
    pacman) pkg_install ca-certificates curl gnupg tar gzip iproute2 util-linux;;
  esac || { bad "Could not install base tools."; return 1; }
  ok "Base tools installed"
}
ensure_build_tools() {          # only used when a native npm module has to be compiled
  case $PM in
    apt) pkg_install build-essential python3 make g++;;
    dnf|yum) pkg_install gcc-c++ make python3;;
    zypper) pkg_install gcc-c++ make python3;;
    pacman) pkg_install base-devel python;;
  esac
}
node_major() { if command -v node >/dev/null 2>&1; then node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0; else echo 0; fi; }
ensure_node() {
  if [ "$(node_major)" -ge 18 ] && command -v npm >/dev/null 2>&1; then :
  else
    warn "Installing Node.js 20"
    case $PM in
      apt) install -d -m 0755 /etc/apt/keyrings
           command -v gpg >/dev/null 2>&1 || pkg_install gnupg
           "${CURL[@]}" https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg \
             && echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" > /etc/apt/sources.list.d/nodesource.list \
             && apt-get update -y && pkg_install nodejs;;
      dnf|yum) local t; t=$(mktemp); "${CURL[@]}" https://rpm.nodesource.com/setup_20.x -o "$t" && bash "$t" >/dev/null; rm -f "$t"; pkg_install nodejs;;
      zypper) pkg_install nodejs20 npm20;;
      pacman) pkg_install nodejs npm;;
    esac
    hash -r
  fi
  [ "$(node_major)" -ge 18 ] || { bad "Node.js >= 18 is required but could not be installed."; return 1; }
  command -v npm >/dev/null 2>&1 || { bad "npm is missing."; return 1; }
  NODE_BIN=$(readlink -f "$(command -v node)")
  ok "Node.js $(node -v), npm $(npm -v)"
}
ensure_cloudflared() {
  if ! command -v cloudflared >/dev/null 2>&1; then
    local done=0
    warn "Installing cloudflared"
    case $PM in
      apt) install -d -m 0755 /usr/share/keyrings
           if "${CURL[@]}" https://pkg.cloudflare.com/cloudflare-main.gpg -o /usr/share/keyrings/cloudflare-main.gpg \
              && echo 'deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main' > /etc/apt/sources.list.d/cloudflared.list \
              && apt-get update -y && pkg_install cloudflared; then done=1; fi;;
      dnf|yum) if "${CURL[@]}" https://pkg.cloudflare.com/cloudflared.repo -o /etc/yum.repos.d/cloudflared.repo && pkg_install cloudflared; then done=1; fi;;
      pacman) if pkg_install cloudflared; then done=1; fi;;
    esac
    if [ $done = 0 ]; then
      [ -n "$CF_ARCH" ] || { bad "Unsupported CPU architecture for cloudflared."; return 1; }
      warn "Package repository unavailable; downloading the official release binary (github.com/cloudflare/cloudflared)"
      "${CURL[@]}" "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$CF_ARCH" -o /usr/local/bin/cloudflared \
        && chmod 755 /usr/local/bin/cloudflared || { bad "cloudflared download failed (check outbound HTTPS)."; return 1; }
    fi
    hash -r
  fi
  command -v cloudflared >/dev/null 2>&1 || { bad "cloudflared is not available."; return 1; }
  CF_BIN=$(readlink -f "$(command -v cloudflared)")
  return 0
}
ensure_sshx() {
  local p
  for p in "$(command -v sshx 2>/dev/null || true)" /usr/local/bin/sshx; do if [ -n "$p" ] && [ -x "$p" ]; then SSHX_PATH=$p; ok "SSHX found: $p"; return 0; fi; done
  warn "Installing SSHX with its official installer (https://sshx.io)"
  local t; t=$(mktemp)
  if "${CURL[@]}" https://sshx.io/get -o "$t"; then sh "$t" >/dev/null 2>&1 || true; fi
  rm -f "$t"; hash -r
  for p in "$(command -v sshx 2>/dev/null || true)" /usr/local/bin/sshx /root/.local/bin/sshx /root/.sshx/bin/sshx /root/.cargo/bin/sshx; do
    if [ -n "$p" ] && [ -x "$p" ]; then
      case $p in /root/*) install -m 755 "$p" /usr/local/bin/sshx; p=/usr/local/bin/sshx;; esac
      SSHX_PATH=$p; ok "SSHX installed: $p"; return 0
    fi
  done
  SSHX_PATH=/usr/local/bin/sshx
  warn "SSHX could not be installed automatically. The panel works; 'Open SSHX' stays unavailable until installed (see README)."
  return 0
}

# ---------- project / system layout ----------
SRC=
project_files_ok() { local f; for f in server.js package.json public/index.html lib/vpsmgr.js lib/lxc-agent.js lib/images.js deploy/quantaforge.service deploy/quantaforge-cloudflared.service deploy/quantaforge-lxc.service scripts/db-status.js; do [ -e "$APP_DIR/$f" ] || { MISSING_FILE=$f; return 1; }; done; }
fix_project_perms() {           # ONLY project items; /root itself and everything else in it is left untouched
  local i; for i in "${PROJECT_ITEMS[@]}" node_modules; do
    [ -e "$APP_DIR/$i" ] || continue
    chown -R root:root "$APP_DIR/$i"; chmod -R u=rwX,go=rX "$APP_DIR/$i"
  done
  [ -f "$APP_DIR/install.sh" ] && chmod 755 "$APP_DIR/install.sh"
  [ -f "$APP_DIR/scripts/audit.sh" ] && chmod 755 "$APP_DIR/scripts/audit.sh"
  return 0
}
copy_items() {                  # copy_items <srcdir>: copies project items into /root, never deletes anything
  local s=$1 i
  for i in "${PROJECT_ITEMS[@]}"; do [ -e "$s/$i" ] && cp -a "$s/$i" "$APP_DIR/"; done
  return 0
}
sync_project() {                # when install.sh was started from another directory, bring the files into /root
  if [ "$(readlink -f "$SRC")" != "$(readlink -f "$APP_DIR")" ] && [ -f "$SRC/server.js" ]; then
    copy_items "$SRC"; ok "Project files copied from $SRC into $APP_DIR (nothing deleted)"
  fi
  fix_project_perms
}
setup_user_dirs() {
  if ! id "$SVC_USER" >/dev/null 2>&1; then
    useradd --system --user-group --home-dir "$DATA_DIR" --no-create-home --shell /bin/bash "$SVC_USER" || { bad "Could not create user $SVC_USER"; return 1; }
    ok "Created system user '$SVC_USER' (password locked, no SSH login)"
  fi
  install -d -m 700 -o "$SVC_USER" -g "$SVC_USER" "$DATA_DIR" "$DATA_DIR/backups"
  install -d -m 700 -o root -g root "$CONF_DIR" "$CONF_DIR/backups"
  ok "Directories ready: $CONF_DIR (root, 0700)  $DATA_DIR ($SVC_USER, 0700)"
}
backup_data() {
  local ts d f; ts=$(date +%Y%m%d-%H%M%S); d="$DATA_DIR/backups/$ts"
  if [ -f "$DB_PATH" ]; then
    mkdir -p "$d"
    for f in "$DB_PATH" "$DB_PATH-wal" "$DB_PATH-shm"; do if [ -f "$f" ]; then cp -p "$f" "$d/"; fi; done
    chown -R "$SVC_USER:$SVC_USER" "$d"; chmod -R go-rwx "$d"; ok "Database backed up to $d"
  fi
  install -d -m 700 -o root -g root "$CONF_DIR/backups"
  for f in "$ENV_FILE" "$CF_ENV"; do if [ -f "$f" ]; then cp -p "$f" "$CONF_DIR/backups/$(basename "$f").$ts"; fi; done
  return 0
}
deps_ok() {
  [ -d "$APP_DIR/node_modules" ] || return 1
  (cd "$APP_DIR" && node -e "for (const m of ['express','better-sqlite3','argon2','helmet','cookie-parser','express-rate-limit','dotenv']) require(m)") >/dev/null 2>&1
}
npm_install_missing() {
  if deps_ok; then ok "npm dependencies already installed and loadable (nothing to install)"; return 0; fi
  warn "Installing missing npm dependencies"
  local cmd=(npm install --omit=dev --no-audit --no-fund); [ -f "$APP_DIR/package-lock.json" ] && cmd=(npm ci --omit=dev --no-audit --no-fund)
  if ! (cd "$APP_DIR" && "${cmd[@]}"); then
    warn "npm install failed - installing build tools for native modules and retrying"
    ensure_build_tools; (cd "$APP_DIR" && "${cmd[@]}") || { bad "npm install failed (see output above)."; return 1; }
  fi
  deps_ok || { bad "Native modules (better-sqlite3 / argon2) failed to load."; return 1; }
  fix_project_perms; ok "npm dependencies installed; native modules load"
}
db_state() {                    # missing | empty | ready | error  (read-only helper; ownership of data dir restored afterwards)
  local r; r=$(cd "$APP_DIR" && DB_PATH="$DB_PATH" "$NODE_BIN" scripts/db-status.js 2>/dev/null) || r=error
  chown -R "$SVC_USER:$SVC_USER" "$DATA_DIR" 2>/dev/null; echo "${r:-error}"
}

# ---------- environment ----------
write_env() {
  [ -f "$ENV_FILE" ] || install -m 600 -o root -g root /dev/null "$ENV_FILE"
  env_set "$ENV_FILE" PORT "$PORT"; env_set "$ENV_FILE" HOST "$BIND"; env_set "$ENV_FILE" DB_PATH "$DB_PATH"
  env_set "$ENV_FILE" COOKIE_SECURE true; env_set "$ENV_FILE" TRUST_PROXY true; env_set "$ENV_FILE" SSHX_BIN "$SSHX_PATH"
  env_has "$ENV_FILE" SESSION_HOURS || env_set "$ENV_FILE" SESSION_HOURS 8
  env_has "$ENV_FILE" HOST_CONTROL_URL || env_set "$ENV_FILE" HOST_CONTROL_URL ""
  env_has "$ENV_FILE" HOST_CONTROL_TOKEN || env_set "$ENV_FILE" HOST_CONTROL_TOKEN ""
  if [ -n "$ADMIN_PW" ] && [ -n "$USER_PW" ]; then env_set "$ENV_FILE" INITIAL_ADMIN_PASSWORD "$(q "$ADMIN_PW")"; env_set "$ENV_FILE" INITIAL_USER_PASSWORD "$(q "$USER_PW")"; fi
  chown root:root "$ENV_FILE"; chmod 600 "$ENV_FILE"
}
collect_passwords() {
  local c
  while :; do
    ask_secret "Initial ADMIN password (12-128 chars, hidden): " ADMIN_PW || return 1
    ask_secret "Confirm admin password: " c || return 1
    [ "$ADMIN_PW" = "$c" ] || { warn "Passwords do not match."; continue; }
    valid_pw "$ADMIN_PW" || { warn "Must be 12-128 characters, no control characters, no leading/trailing space."; continue; }
    break
  done
  while :; do
    ask_secret "Initial USER password (12-128 chars, hidden): " USER_PW || return 1
    ask_secret "Confirm user password: " c || return 1
    [ "$USER_PW" = "$c" ] || { warn "Passwords do not match."; continue; }
    valid_pw "$USER_PW" || { warn "Must be 12-128 characters, no control characters, no leading/trailing space."; continue; }
    [ "$USER_PW" != "$ADMIN_PW" ] || { warn "User and admin passwords must differ."; continue; }
    break
  done
}
validate_env() {                # validates the written env file (never prints secret values)
  local e=0 v
  [ "$(stat -c '%a %U' "$ENV_FILE")" = "600 root" ] || { bad "$ENV_FILE must be root-owned with mode 600"; e=1; }
  v=$(env_get "$ENV_FILE" PORT); [ "$v" = "$PORT" ] || { bad "PORT in env is '$v', expected $PORT"; e=1; }
  v=$(env_get "$ENV_FILE" HOST); [ "$v" = "$BIND" ] || { bad "HOST in env is '$v', expected $BIND (localhost only)"; e=1; }
  v=$(env_get "$ENV_FILE" DB_PATH); [ -n "$v" ] && [ -d "$(dirname "$v")" ] || { bad "DB_PATH missing or its directory does not exist"; e=1; }
  v=$(env_get "$ENV_FILE" SSHX_BIN); [ -n "$v" ] || { bad "SSHX_BIN is empty"; e=1; }
  if [ "$1" != ready ]; then
    [ -n "$(env_get "$ENV_FILE" INITIAL_ADMIN_PASSWORD)" ] && [ -n "$(env_get "$ENV_FILE" INITIAL_USER_PASSWORD)" ] || { bad "Database has no credentials and initial passwords are not set"; e=1; }
  fi
  [ $e = 0 ] && ok "Environment configuration valid ($ENV_FILE, root:root 600)"
  return $e
}

# ---------- systemd units ----------
render_unit() { sed -e "s#@NODE_BIN@#$NODE_BIN#g" -e "s#@CLOUDFLARED_BIN@#$CF_BIN#g" -e "s#@METRICS@#$METRICS#g" "$1" > "$2" && chmod 644 "$2"; }
port_busy() { command -v ss >/dev/null && [ -n "$(ss -ltnH "sport = :$PORT" 2>/dev/null)" ]; }
diag_app() { echo "  --- application logs (systemd journal, last 30 lines) ---"; journalctl -u "$APP_SVC" -n 30 --no-pager 2>&1 | redact; }

# ================= CLOUDFLARE =================
cf_token_ok() {
  [ -s "$CF_ENV" ] && [ -n "$(env_get "$CF_ENV" TUNNEL_TOKEN)" ] && [ "$(stat -c '%a %U' "$CF_ENV")" = "600 root" ]
}
cf_inv_logs() {                 # logs of the CURRENT service invocation only (so old runs never fake a success)
  local inv; inv=$(systemctl show -p InvocationID --value "$CF_SVC" 2>/dev/null)
  if [ -n "$inv" ]; then journalctl "_SYSTEMD_INVOCATION_ID=$inv" --no-pager -o cat 2>/dev/null
  else journalctl -u "$CF_SVC" -n 300 --no-pager -o cat 2>/dev/null; fi
}
cf_ready_count() {              # prints number of active edge connections; prints nothing if the metrics endpoint is unreachable
  local body; body=$(curl -s --max-time 3 "http://$METRICS/ready" 2>/dev/null) || true
  if [[ "$body" =~ \"readyConnections\":([0-9]+) ]]; then echo "${BASH_REMATCH[1]}"; fi
}
cf_logs_registered() { cf_inv_logs | grep -q 'Registered tunnel connection'; }
cf_tunnel_id() {                # tunnel UUID is public information; the secret part of the token is never shown
  local t; t=$(env_get "$CF_ENV" TUNNEL_TOKEN) || return 1
  printf '%s' "$t" | base64 -d 2>/dev/null | grep -oE '"t":"[0-9a-fA-F-]{36}"' | head -1 | cut -d'"' -f4
}
cf_diag() {                     # classify and show ACTUAL errors from the tunnel logs (tokens redacted)
  local logs a d n
  logs=$(cf_inv_logs | redact)
  a=$(grep -iE 'unauthorized|invalid tunnel|tunnel secret|token is not valid|not valid|failed to (parse|unmarshal|decode)|authentication' <<<"$logs" | tail -3)
  d=$(grep -iE 'no such host|server misbehaving|lookup [a-z0-9.-]+|dns' <<<"$logs" | tail -3)
  n=$(grep -iE 'i/o timeout|connection refused|network is unreachable|no route to host|context deadline|handshake|failed to dial|unable to establish|dial tcp|retrying connection' <<<"$logs" | tail -3)
  [ -n "$a" ] && { echo "  ${R}Authentication error (wrong, revoked or malformed token):${N}"; sed 's/^/      /' <<<"$a"; }
  [ -n "$d" ] && { echo "  ${R}DNS error (this VPS cannot resolve Cloudflare hostnames):${N}"; sed 's/^/      /' <<<"$d"; }
  [ -n "$n" ] && { echo "  ${R}Network error (outbound HTTPS/7844 to Cloudflare blocked or unstable):${N}"; sed 's/^/      /' <<<"$n"; }
  if [ -z "$a$d$n" ]; then echo "  No known error pattern. Last log lines:"; tail -8 <<<"$logs" | sed 's/^/      /'; fi
  return 0
}
cf_auth_error() { cf_inv_logs | grep -qiE 'unauthorized|invalid tunnel|token is not valid|failed to (parse|unmarshal|decode)'; }
cf_show_logs() { echo "  --- Cloudflare tunnel logs (last 100 lines, tokens redacted) ---"; journalctl -u "$CF_SVC" -n 100 --no-pager -o cat 2>&1 | redact; }

cf_prompt_token() {             # sets CF_TOKEN; refuses empty / malformed input
  local raw
  while :; do
    ask_secret "Cloudflare Tunnel token (hidden, 'q' to cancel): " raw || return 1
    [ "$raw" = q ] && return 1
    CF_TOKEN=$(normalize_token "$raw")
    if [ -z "$CF_TOKEN" ]; then bad "Token field is empty."; continue; fi
    if valid_token "$CF_TOKEN"; then unset raw; return 0; fi
    warn "That does not look like a Cloudflare Tunnel token (long base64 string, usually starting with 'eyJ')."
  done
}
cf_write_token() {
  [ -n "$CF_TOKEN" ] || { bad "No token to save."; return 1; }
  install -d -m 700 -o root -g root "$CONF_DIR"
  [ -f "$CF_ENV" ] || install -m 600 -o root -g root /dev/null "$CF_ENV"
  env_set "$CF_ENV" TUNNEL_TOKEN "$(q "$CF_TOKEN")"
  chown root:root "$CF_ENV"; chmod 600 "$CF_ENV"
  CF_TOKEN=
}
cf_install_unit() {
  [ -f "$APP_DIR/deploy/quantaforge-cloudflared.service" ] || { bad "Missing $APP_DIR/deploy/quantaforge-cloudflared.service"; return 1; }
  render_unit "$APP_DIR/deploy/quantaforge-cloudflared.service" /etc/systemd/system/$CF_SVC.service || { bad "Could not write the tunnel unit."; return 1; }
  systemctl daemon-reload; systemctl enable "$CF_SVC" >/dev/null 2>&1
  ok "Tunnel service configured (HTTP/2, token from $CF_ENV)"
}
cf_restart_service() { systemctl reset-failed "$CF_SVC" >/dev/null 2>&1; systemctl restart "$CF_SVC" || { bad "systemctl could not start $CF_SVC"; return 1; }; }

st_cf_connected() {
  systemctl is-active --quiet "$CF_SVC" || return 1
  local n; n=$(cf_ready_count)
  if [ -n "$n" ]; then [ "$n" -gt 0 ]; else cf_logs_registered; fi
}
cf_verify() {                   # all required Cloudflare checks; returns 0 only when the tunnel really is connected
  local pid n via ready_via_logs=0 start=$SECONDS proto
  echo; echo "${B}Cloudflare connection check${N}"
  if command -v cloudflared >/dev/null 2>&1; then ok "Cloudflared Installed ($(cloudflared --version 2>&1 | head -1))"
  else bad "Cloudflared is not installed"; return 1; fi
  if cf_token_ok; then ok "Token Configuration Saved ($CF_ENV, root:root, mode 600)"; local tid; tid=$(cf_tunnel_id); [ -n "$tid" ] && info "Tunnel ID: $tid"
  else bad "Token configuration missing or insecure ($CF_ENV must hold the token, root:root, mode 600)"; return 1; fi
  local w=0; until systemctl is-active --quiet "$CF_SVC"; do
    [ $w -ge 10 ] && { bad "Tunnel service is not running (state: $(systemctl is-active "$CF_SVC" 2>&1))"; cf_diag; return 1; }
    sleep 1; w=$((w+1)); done
  ok "Tunnel Service Running"
  pid=$(systemctl show -p MainPID --value "$CF_SVC" 2>/dev/null)
  if [ -n "$pid" ] && [ "$pid" -gt 0 ] 2>/dev/null && [ -d "/proc/$pid" ]; then ok "Tunnel Process Running (PID $pid)"
  else bad "Tunnel service is active but no tunnel process was found"; cf_diag; return 1; fi
  printf "      waiting for Cloudflare to register the tunnel (max %ss) " "$CF_WAIT"
  while :; do
    n=$(cf_ready_count)
    if [ -n "$n" ] && [ "$n" -gt 0 ]; then break; fi
    if [ -z "$n" ] && cf_logs_registered; then ready_via_logs=1; break; fi
    if ! systemctl is-active --quiet "$CF_SVC" && [ $((SECONDS-start)) -gt 20 ]; then break; fi
    if [ $((SECONDS-start)) -ge 8 ] && cf_auth_error; then break; fi
    [ $((SECONDS-start)) -ge "$CF_WAIT" ] && break
    printf '.'; sleep 2
  done
  echo
  if { [ -n "${n:-}" ] && [ "$n" -gt 0 ]; } || [ $ready_via_logs = 1 ]; then
    if [ $ready_via_logs = 1 ]; then via="confirmed from cloudflared logs"; else via="$n active edge connection(s)"; fi
    ok "Cloudflare Connection Established ($via)"
    proto=$(cf_inv_logs | grep -oE 'protocol=[a-z0-9]+' | tail -1)
    [ -n "$proto" ] && info "Transport: ${proto#protocol=}"
    [ "$proto" = "protocol=quic" ] && warn "Tunnel registered over QUIC, not HTTP/2 - check the unit's --protocol http2 flag."
    return 0
  fi
  bad "Cloudflare Connection NOT established (service runs, but the tunnel is not registered with Cloudflare)"
  cf_diag
  return 1
}
cf_failure_menu() {             # returns 0 = re-check, 1 = abort
  local c
  while :; do
    echo; echo "  ${B}1)${N} Retry   ${B}2)${N} Reconfigure Token   ${B}3)${N} View Logs   ${B}4)${N} Abort"
    ask "  Choose [1-4]: " c || return 1
    case $c in
      1) cf_restart_service; return 0;;
      2) if cf_prompt_token && cf_write_token; then cf_restart_service; return 0; fi;;
      3) cf_show_logs;;
      4) return 1;;
    esac
  done
}
cf_connect_flow() {             # STEP 1 + STEP 2.  $1 = reconfigure forces a new token prompt
  step "STEP 1 - Cloudflare setup"
  ensure_min_tools || return 1
  ensure_cloudflared || return 1
  ok "cloudflared ready: $(cloudflared --version 2>&1 | head -1)"
  if [ "${1:-}" = reconfigure ] || ! cf_token_ok; then
    cf_prompt_token || { bad "No token entered - Cloudflare setup cancelled."; return 1; }
    cf_write_token || return 1
  elif ! confirm "A Cloudflare Tunnel token is already saved. Keep it?" Y; then
    cf_prompt_token || { bad "No token entered - Cloudflare setup cancelled."; return 1; }
    cf_write_token || return 1
  fi
  cf_install_unit || return 1
  cf_restart_service || return 1
  step "STEP 2 - Verifying the Cloudflare connection"
  while :; do
    cf_verify && return 0
    cf_failure_menu || { bad "Cloudflare is not connected - the application will NOT be started."; return 1; }
  done
}

# ---------- ingress / public URL ----------
cf_ingress() {                  # prints "hostname|service" per ingress rule from the tunnel's current remote config; fails if not seen yet
  local line cfg
  line=$(cf_inv_logs | grep 'Updated to new configuration' | tail -1)
  [ -n "$line" ] || return 1
  if [[ "$line" == *'config="'* ]]; then cfg=${line#*config=\"}; else cfg=${line#*config=}; fi
  cfg=${cfg%\"*}; cfg=${cfg//\\\"/\"}
  printf '%s' "$cfg" | sed 's/},{"/}\n{"/g' | grep '"service"' | while IFS= read -r e; do
    local h s
    h=$(grep -oE '"hostname":"[^"]*"' <<<"$e" | head -1 | cut -d'"' -f4)
    s=$(grep -oE '"service":"[^"]*"' <<<"$e" | head -1 | cut -d'"' -f4)
    printf '%s|%s\n' "$h" "$s"
  done
}
cf_route_check() {              # does the tunnel route a hostname to http://127.0.0.1:5000 ?  sets ROUTE_STATE: ok|wrong|nohost|catchall|noconfig
  ROUTE_STATE=noconfig; ROUTE_MSG=; GOOD_HOSTS=(); BAD_ROUTES=()
  local rules h s catch=0 w=0
  while :; do rules=$(cf_ingress) && break; [ $w -ge "${ROUTE_WAIT:-20}" ] && break; sleep 2; w=$((w+2)); done
  if [ -z "$rules" ]; then ROUTE_MSG="Tunnel is connected but its ingress configuration was not found in the logs yet."; return 1; fi
  while IFS='|' read -r h s; do
    if route_ok_service "$s"; then if [ -n "$h" ]; then GOOD_HOSTS+=("$h"); else catch=1; fi
    elif [ -n "$h" ]; then BAD_ROUTES+=("$h -> $s"); fi
  done <<<"$rules"
  if [ ${#GOOD_HOSTS[@]} -gt 0 ]; then ROUTE_STATE=ok; ROUTE_MSG="Hostname(s) routed to http://127.0.0.1:$PORT: ${GOOD_HOSTS[*]}"; return 0; fi
  if [ ${#BAD_ROUTES[@]} -gt 0 ]; then ROUTE_STATE=wrong; ROUTE_MSG="Tunnel is connected, but no hostname routes to http://127.0.0.1:$PORT. Current routes: ${BAD_ROUTES[*]}"; return 1; fi
  if [ $catch = 1 ]; then ROUTE_STATE=catchall; ROUTE_MSG="Tunnel has a catch-all route to the panel but no named hostname, so no public URL can be derived."; return 1; fi
  ROUTE_STATE=nohost; ROUTE_MSG="Tunnel is connected, but no Public Hostname is configured in Cloudflare."; return 1
}
cf_public_check() {             # verifies a hostname really serves the panel over HTTPS; only then is a URL reported
  PUB_STATE=unavailable; PUB_URL=; PUB_MSG=
  [ "$ROUTE_STATE" = ok ] || { PUB_MSG=$ROUTE_MSG; return 1; }
  local h code tmp
  for h in "${GOOD_HOSTS[@]}"; do
    [[ "$h" == \** ]] && continue
    tmp=$(mktemp); code=$(curl -s -o "$tmp" -w '%{http_code}' --max-time 15 "https://$h/api/branding" 2>/dev/null); code=${code:-000}
    if [ "$code" = 200 ] && grep -q panel_name "$tmp"; then rm -f "$tmp"; PUB_STATE=available; PUB_URL="https://$h"; PUB_MSG=; return 0; fi
    rm -f "$tmp"
    case $code in
      000) PUB_MSG="https://$h is not reachable (DNS record missing/not propagated, TLS or network problem).";;
      530|1033) PUB_MSG="https://$h: Cloudflare reports the tunnel is unreachable (HTTP $code).";;
      502|503|504) PUB_MSG="https://$h: Cloudflare reached the tunnel but the origin did not answer (HTTP $code) - wrong service URL/port.";;
      *) PUB_MSG="https://$h answered HTTP $code instead of serving the panel.";;
    esac
  done
  [ -n "$PUB_MSG" ] || PUB_MSG="Only wildcard hostnames are configured; cannot verify a concrete URL."
  return 1
}

# ================= LXC DEPLOYMENT BACKEND =================
lxc_cli() { command -v incus 2>/dev/null || command -v lxc 2>/dev/null || true; }
lxc_enabled() { [ "$(env_get "$ENV_FILE" LXC_ENABLED 2>/dev/null)" = true ]; }
agent_get() { curl -fsS --max-time 5 --unix-socket "$AGENT_SOCK" "http://localhost$1" 2>&1; }
lxc_init_storage() {            # creates a quota-capable btrfs loop pool + NAT bridge (falls back to a dir pool with a warning)
  local cli=$1 init avail gb
  if [ "$(basename "$cli")" = incus ]; then init=("$cli" admin init); else init=(lxd init); fi
  avail=$(df --output=avail -BG / 2>/dev/null | tail -1 | tr -dc '0-9'); gb=$(( ${avail:-10} * 6 / 10 )); [ "$gb" -gt 100 ] && gb=100; [ "$gb" -lt 5 ] && gb=5
  warn "No LXC storage pool found - initialising ($gb GiB btrfs loop pool + NAT bridge)"
  if "${init[@]}" --auto --storage-backend=btrfs --storage-create-loop="$gb"; then ok "LXC initialised (btrfs pool, disk quotas enforced)"; return 0; fi
  warn "btrfs pool failed - falling back to a dir pool (disk limits may NOT be enforced)"
  "${init[@]}" --auto --storage-backend=dir && ok "LXC initialised (dir pool)" || { bad "LXC initialisation failed (see output above)"; return 1; }
}
lxc_setup_flow() {              # enables one-click VPS deployment: Incus/LXD + root agent (unix socket) ; idempotent
  step "LXC deployment backend"
  if ! lxc_enabled; then
    confirm "Enable one-click LXC VPS deployment on this host?" Y || { env_set "$ENV_FILE" LXC_ENABLED false; warn "LXC deployment skipped (re-run menu 4 to enable)"; return 0; }
  fi
  local cli; cli=$(lxc_cli)
  if [ -z "$cli" ]; then
    case $PM in
      apt) confirm "Incus (LXC container manager) is not installed. Install it now?" Y || { bad "Incus/LXD is required for LXC deployment."; return 1; }
           apt-get update -y >/dev/null; pkg_install incus btrfs-progs || { bad "Could not install incus (needs Debian 13 / Ubuntu 24.04 or newer)."; return 1; };;
      *)   bad "Install Incus or LXD manually, then run menu 4 again."; return 1;;
    esac
    hash -r; cli=$(lxc_cli); [ -n "$cli" ] || { bad "incus/lxc still not found after installation."; return 1; }
  fi
  if [ "$(basename "$cli")" = incus ]; then systemctl enable --now incus.socket incus.service >/dev/null 2>&1 || true; fi
  "$cli" query /1.0 >/dev/null 2>&1 || { bad "Cannot talk to the $(basename "$cli") daemon: $("$cli" query /1.0 2>&1 | head -1)"; return 1; }
  ok "Container manager: $(basename "$cli") $("$cli" --version 2>/dev/null | head -1)"
  "$cli" query /1.0/storage-pools 2>/dev/null | grep -q '/1.0/storage-pools/' || lxc_init_storage "$cli" || return 1
  [ -f "$LXC_ENV" ] || install -m 600 -o root -g root /dev/null "$LXC_ENV"
  env_set "$LXC_ENV" LXC_CLI "$cli"; env_set "$LXC_ENV" LXC_AGENT_SOCKET "$AGENT_SOCK"; env_set "$LXC_ENV" LXC_AGENT_GROUP "$SVC_USER"; env_set "$LXC_ENV" SSHX_BIN "$SSHX_PATH"
  chown root:root "$LXC_ENV"; chmod 600 "$LXC_ENV"
  env_set "$ENV_FILE" LXC_ENABLED true; env_set "$ENV_FILE" LXC_AGENT_SOCKET "$AGENT_SOCK"; chown root:root "$ENV_FILE"; chmod 600 "$ENV_FILE"
  render_unit "$APP_DIR/deploy/quantaforge-lxc.service" /etc/systemd/system/$LXC_SVC.service || { bad "Could not write the LXC agent unit."; return 1; }
  systemctl daemon-reload; systemctl enable "$LXC_SVC" >/dev/null 2>&1; systemctl reset-failed "$LXC_SVC" >/dev/null 2>&1; systemctl restart "$LXC_SVC"
  local i out; for i in $(seq 1 15); do out=$(agent_get /health) && grep -q '"ok":true' <<<"$out" && break; out=; sleep 1; done
  if [ -z "$out" ]; then bad "LXC agent did not start"; journalctl -u "$LXC_SVC" -n 20 --no-pager 2>&1 | redact; return 1; fi
  ok "LXC agent running (root, unix socket $AGENT_SOCK, group $SVC_USER)"
  out=$(agent_get /capacity) || { bad "LXC agent cannot read host capacity: $out"; return 1; }
  ok "Host capacity readable: $(grep -oE '"cpuCores":[0-9]+' <<<"$out"), pool driver $(grep -oE '"poolDriver":"[a-z]+"' <<<"$out" | cut -d'"' -f4)"
  [ -x "$SSHX_PATH" ] || warn "SSHX binary missing on the host ($SSHX_PATH): new VPS will deploy without SSHX until it is installed."
  warn "The old shared 'user' password (host-level SSHX) is now disabled. Users are created by the admin in the panel."
}

# ================= APPLICATION =================
wait_panel() {
  local i
  for i in $(seq 1 45); do
    if systemctl is-active --quiet "$APP_SVC" && curl -fsS -o /dev/null --max-time 3 "$HEALTH_URL" 2>/dev/null; then return 0; fi
    sleep 1
  done
  return 1
}
health_ok() { curl -fsS --max-time 3 "$HEALTH_URL" 2>/dev/null | grep -q panel_name; }
verify_panel() {
  local code binds
  code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "http://127.0.0.1:$PORT/api/admin/overview" || true)
  if [ "$code" = 401 ]; then ok "Admin API rejects unauthenticated requests (HTTP 401)"; else bad "Unexpected admin API response ($code) - authentication check failed."; return 1; fi
  if command -v ss >/dev/null; then
    binds=$(ss -ltnH "sport = :$PORT" | awk '{print $4}')
    if echo "$binds" | grep -qv '^127\.0\.0\.1:'; then bad "Port $PORT is not bound to localhost only: $binds"; return 1; fi
    ok "Port $PORT bound to 127.0.0.1 only (not exposed publicly)"
  fi
}
app_start_flow() {              # Section 3: only after Cloudflare is verified
  step "STEP 3 - QuantaForge (starts only after Cloudflare is connected)"
  if ! st_cf_connected; then bad "Cloudflare tunnel is not connected - refusing to start QuantaForge. Use menu 2 or 3 first."; return 1; fi
  ok "Cloudflare connection confirmed"
  [ -n "$PM" ] || detect_platform || return 1
  echo "  1/8 Project files"
  if project_files_ok; then ok "Project files present in $APP_DIR"; else bad "Missing project file: $APP_DIR/$MISSING_FILE"; return 1; fi
  fix_project_perms
  echo "  2/8 Dependencies (only missing ones are installed)"
  ensure_min_tools || return 1; ensure_node || return 1; ensure_sshx; setup_user_dirs || return 1; npm_install_missing || return 1
  echo "  3/8 Environment"
  local st; st=$(db_state)
  if [ "$st" = ready ]; then ok "Database already holds admin and user credentials (kept as is)"; ADMIN_PW=; USER_PW=
  elif [ -n "$(env_get "$ENV_FILE" INITIAL_ADMIN_PASSWORD 2>/dev/null)" ] && [ -n "$(env_get "$ENV_FILE" INITIAL_USER_PASSWORD 2>/dev/null)" ]; then ok "Initial passwords already stored for first start"
  else tty_ok || { bad "Initial passwords are needed (interactive terminal required)."; return 1; }
       collect_passwords || return 1; fi
  write_env; ADMIN_PW=; USER_PW=
  validate_env "$st" || return 1
  lxc_setup_flow || warn "LXC deployment backend is NOT ready - the panel will start, but Deploy VPS stays unavailable until this is fixed (menu 4)."
  echo "  4/8 Port $PORT"
  if systemctl is-active --quiet "$APP_SVC"; then systemctl stop "$APP_SVC"; fi
  backup_data
  if port_busy; then bad "Port $PORT is already in use by another process: $(ss -ltnpH "sport = :$PORT" | awk '{print $6}' | head -1)"; return 1; fi
  ok "Port $PORT is free"
  echo "  5/8 Starting systemd service"
  render_unit "$APP_DIR/deploy/quantaforge.service" /etc/systemd/system/$APP_SVC.service || { bad "Could not write the application unit."; return 1; }
  systemctl daemon-reload; systemctl enable "$APP_SVC" >/dev/null 2>&1; systemctl reset-failed "$APP_SVC" >/dev/null 2>&1
  systemctl restart "$APP_SVC" || { bad "systemctl could not start $APP_SVC"; diag_app; return 1; }
  echo "  6/8 Service state + 7/8 local health check"
  if ! wait_panel; then
    bad "Application did not become healthy. systemd state: $(systemctl is-active "$APP_SVC" 2>&1)"
    echo "  Health-check error: $(curl -sS -o /dev/null --max-time 3 "$HEALTH_URL" 2>&1 | head -1)"
    diag_app; return 1
  fi
  ok "Application Service Running"
  health_ok && ok "Local health check passed ($HEALTH_URL)" || { bad "Health endpoint answered but did not return the panel's JSON"; diag_app; return 1; }
  verify_panel || return 1
  [ "$(db_state)" = ready ] || { bad "Database was not initialised (admin/user credentials missing)."; diag_app; return 1; }
  ok "Database initialised: $DB_PATH"
  if [ "$st" != ready ]; then sed -i -E '/^INITIAL_(ADMIN|USER)_PASSWORD=/d' "$ENV_FILE"; ok "Initial passwords removed from $ENV_FILE (only Argon2id hashes remain in the DB)"; fi
  echo "  8/8 Cloudflare route -> local port"
  if cf_route_check; then ok "$ROUTE_MSG"; cf_public_check && ok "Public HTTPS URL verified: $PUB_URL" || warn "$PUB_MSG"
  else warn "$ROUTE_MSG"; fi
  step "Security audit"; bash "$APP_DIR/scripts/audit.sh" "$ENV_FILE" "$CF_ENV" 2>&1 | tail -4
  return 0
}
app_restart_flow() {
  step "Restarting QuantaForge"
  systemctl restart "$APP_SVC" || { bad "systemctl could not restart $APP_SVC"; diag_app; return 1; }
  if wait_panel && health_ok; then ok "Application Service Running"; ok "Local health check passed ($HEALTH_URL)"
  else bad "Application unhealthy after restart. systemd state: $(systemctl is-active "$APP_SVC" 2>&1)"; echo "  Health-check error: $(curl -sS -o /dev/null --max-time 3 "$HEALTH_URL" 2>&1 | head -1)"; diag_app; return 1; fi
}
update_flow() {
  step "Update QuantaForge"
  [ -n "$PM" ] || detect_platform || return 1
  local p tmp srcdir; ask "Path to the new version (.zip or folder), blank = only refresh dependencies/units from current files: " p || return 1
  backup_data
  if [ -n "$p" ]; then
    p=${p/#\~/$HOME}; tmp=$(mktemp -d)
    if [ -f "$p" ]; then
      command -v unzip >/dev/null 2>&1 || pkg_install unzip
      unzip -q -o "$p" -d "$tmp" || { bad "Could not unzip $p"; rm -rf "$tmp"; return 1; }
    elif [ -d "$p" ]; then cp -a "$p/." "$tmp/"
    else bad "Not found: $p"; rm -rf "$tmp"; return 1; fi
    srcdir=$tmp; [ -f "$srcdir/server.js" ] || { local d; d=$(find "$tmp" -maxdepth 2 -name server.js -print -quit); [ -n "$d" ] && srcdir=$(dirname "$d"); }
    [ -f "$srcdir/server.js" ] && [ -f "$srcdir/package.json" ] || { bad "No server.js/package.json found in the update."; rm -rf "$tmp"; return 1; }
    copy_items "$srcdir"; rm -rf "$tmp"; ok "New files copied into $APP_DIR (existing data, env files and database untouched)"
  fi
  fix_project_perms
  ensure_node || return 1
  (cd "$APP_DIR" && npm install --omit=dev --no-audit --no-fund) || { bad "npm install failed"; return 1; }
  deps_ok || { bad "Dependencies failed to load after update."; return 1; }
  ok "Dependencies up to date"
  render_unit "$APP_DIR/deploy/quantaforge.service" /etc/systemd/system/$APP_SVC.service
  [ -n "$CF_BIN" ] || CF_BIN=$(readlink -f "$(command -v cloudflared 2>/dev/null)" 2>/dev/null)
  [ -n "$CF_BIN" ] && render_unit "$APP_DIR/deploy/quantaforge-cloudflared.service" /etc/systemd/system/$CF_SVC.service
  if lxc_enabled; then render_unit "$APP_DIR/deploy/quantaforge-lxc.service" /etc/systemd/system/$LXC_SVC.service; fi
  systemctl daemon-reload
  if lxc_enabled; then systemctl restart "$LXC_SVC" && ok "LXC agent restarted"; fi
  if systemctl is-active --quiet "$CF_SVC"; then ok "Tunnel left running"; fi
  app_restart_flow
}

# ================= STATUS =================
st_deps() { [ "$(node_major)" -ge 18 ] && command -v npm >/dev/null 2>&1 && deps_ok; }
st_app_service() { systemctl is-active --quiet "$APP_SVC"; }
cl() { if [ "$2" = good ]; then printf '%s%s%s' "$G" "$1" "$N"; else printf '%s%s%s' "$R" "$1" "$N"; fi; }
line() { printf '  %-22s: %s\n' "$1" "$2"; }
dashboard() {
  local ci ap hc pub_note=
  echo; echo "${B}QUANTAFORGE INSTALLER${N}"; echo "  ------------------------------------------"
  [ "$(id -u)" -eq 0 ] && line "Root Access" "$(cl OK good)" || line "Root Access" "$(cl FAILED bad)"
  st_deps && line "Dependencies" "$(cl INSTALLED good)" || line "Dependencies" "$(cl MISSING bad)"
  command -v cloudflared >/dev/null 2>&1 && line "Cloudflared" "$(cl INSTALLED good)" || line "Cloudflared" "$(cl MISSING bad)"
  cf_token_ok && line "Token Configuration" "$(cl SAVED good)" || line "Token Configuration" "$(cl MISSING bad)"
  systemctl is-active --quiet "$CF_SVC" && line "Cloudflare Service" "$(cl RUNNING good)" || line "Cloudflare Service" "$(cl STOPPED bad)"
  ci=0; st_cf_connected && ci=1
  [ $ci = 1 ] && line "Cloudflare Tunnel" "$(cl CONNECTED good)" || line "Cloudflare Tunnel" "$(cl DISCONNECTED bad)"
  ap=0; st_app_service && ap=1
  [ $ap = 1 ] && line "Application Service" "$(cl RUNNING good)" || line "Application Service" "$(cl STOPPED bad)"
  hc=0; [ $ap = 1 ] && health_ok && hc=1
  if lxc_enabled; then if agent_get /health | grep -q '"ok":true'; then line "LXC Agent" "$(cl RUNNING good)"; else line "LXC Agent" "$(cl STOPPED bad)"; fi; fi
  [ $hc = 1 ] && line "Local Health Check" "$(cl PASS good)" || line "Local Health Check" "$(cl FAIL bad)"
  ROUTE_STATE=noconfig
  if [ $ci = 1 ] && [ $hc = 1 ] && cf_route_check && cf_public_check; then line "Public HTTPS URL" "$(cl AVAILABLE good)  $PUB_URL"
  else line "Public HTTPS URL" "$(cl UNAVAILABLE bad)"
    if [ $ci = 0 ]; then pub_note="Tunnel is not connected."; elif [ $hc = 0 ]; then pub_note="Application is not healthy locally."; else pub_note=$PUB_MSG; fi
  fi
  echo "  ------------------------------------------"
  [ -n "$pub_note" ] && echo "  ${Y}Note:${N} $pub_note"
  if [ $ci = 1 ] && [ $hc = 1 ] && [ "$ROUTE_STATE" != ok ] && [ "$ROUTE_STATE" != noconfig ]; then
    echo "  ${Y}Fix in Cloudflare:${N} Zero Trust -> Networks -> Tunnels -> your tunnel -> Public Hostname -> add hostname, Service HTTP, URL 127.0.0.1:$PORT"
  fi
  return 0
}

# ================= MENU =================
need_root() {
  if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then echo "Root access required - re-running with sudo..."; exec sudo bash "$0" "$@"; fi
    echo "${R}[✗] FAILED${N} Root Access: run as root (this installer manages systemd and /etc)."; exit 1
  fi
  ok "Root Access: OK (uid 0)"
}
install_all() {
  detect_platform || return 1
  cf_connect_flow auto || return 1
  app_start_flow || { echo; bad "Application step failed - see the actual errors above. Fix and use menu 4 / 5 to retry."; dashboard; return 1; }
  dashboard
  echo; echo "${G}${B}QuantaForge installation finished.${N}  Logs: menu 7 (Cloudflare), 8 (application)."
}
action() {
  case "$1" in
    1|install)    install_all;;
    2|cloudflare) detect_platform && cf_connect_flow reconfigure;;
    3|check)      step "Cloudflare connection check"; ensure_min_tools >/dev/null 2>&1
                  while :; do cf_verify && break; cf_failure_menu || break; done;;
    4|start)      app_start_flow && dashboard;;
    5|restart)    app_restart_flow && dashboard;;
    6|status)     dashboard;;
    7|cflogs)     cf_show_logs;;
    8|applogs)    echo "  --- application logs (last 100 lines, tokens redacted) ---"; journalctl -u "$APP_SVC" -n 100 --no-pager 2>&1 | redact;;
    9|update)     update_flow && dashboard;;
    *) echo "Unknown option: $1"; return 1;;
  esac
}
menu() {
  local c
  while :; do
    echo; echo "${B}QUANTAFORGE INSTALLER${N}  (project: $APP_DIR)"
    cat <<'M'
  1. Install QuantaForge
  2. Connect / Reconfigure Cloudflare
  3. Check Cloudflare Connection
  4. Start QuantaForge
  5. Restart QuantaForge
  6. Full Status Check
  7. View Cloudflare Logs
  8. View Application Logs
  9. Update QuantaForge
  10. Exit
M
    ask "Select [1-10]: " c || { echo; return 0; }
    case $c in 10|q|exit) return 0;; *) action "$c" || true;; esac
  done
}
usage() { sed -n '2,5p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

main() {
  case "${1:-}" in -h|--help|help) usage;; esac
  need_root "$@"
  SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
  case "${1:-menu}" in status|cflogs|applogs|6|7|8) :;; *) tty_ok || { bad "An interactive terminal is required (hidden password/token prompts). Use an SSH session, not a pipe."; exit 1; };; esac
  sync_project
  if [ "${1:-menu}" = menu ]; then menu; else action "$1"; fi
}
if [ "${BASH_SOURCE[0]}" = "$0" ]; then main "$@"; fi
